"""Generates demo images for the Screenshot + QR scanners."""
import qrcode
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path

out = Path(__file__).parent

def font(size):
    for f in ["C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/arial.ttf"]:
        try: return ImageFont.truetype(f, size)
        except OSError: pass
    return ImageFont.load_default()

def sms(name, sender, lines):
    img = Image.new("RGB", (1080, 900), "#f4f6fb"); d = ImageDraw.Draw(img)
    d.text((60, 50), sender, fill="#111827", font=font(52))
    d.rounded_rectangle((50, 170, 1000, 190 + 72 * len(lines) + 60), 40, fill="white")
    for i, l in enumerate(lines):
        d.text((90, 210 + 72 * i), l, fill="#111827", font=font(46))
    img.save(out / name)

sms("scam_sms_screenshot.png", "VM-SBIBNK", ["Dear Customer, your SBI KYC", "has expired. Your account will", "be blocked today. Update now:", "http://sbi-kyc-update.top"])
sms("scam_electricity.png", "+91 98765 43210", ["Dear consumer, your electricity", "will be disconnected tonight", "at 9:30pm. Call 9876543210", "immediately."])
sms("safe_otp.png", "AX-HDFCBK", ["482913 is your OTP for txn of", "Rs 1,250 at HDFC Bank.", "Do not share it with anyone."])

def qr(name, data, caption):
    q = qrcode.make(data, box_size=14, border=3).convert("RGB")
    img = Image.new("RGB", (q.width, q.height + 120), "white"); img.paste(q, (0, 0))
    ImageDraw.Draw(img).text((40, q.height + 30), caption, fill="#111827", font=font(44))
    img.save(out / name)

qr("qr_upi_refund_scam.png", "upi://pay?pa=9876543210@ybl&pn=Refund%20Desk&am=4999&tn=Scan%20to%20receive%20refund&cu=INR", "Scan to RECEIVE your refund!")
qr("qr_phishing_link.png", "http://amaz0n-offer.xyz/win", "Scan for Diwali gift")
qr("qr_safe_link.png", "https://www.amazon.in", "amazon.in")
print("ok", sorted(p.name for p in out.glob("*.png")))
