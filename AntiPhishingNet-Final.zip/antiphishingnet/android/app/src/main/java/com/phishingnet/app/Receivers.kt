package com.phishingnet.app

import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads incoming SMS (read-only; the original SMS is never deleted). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (!Repo.scope(c, "sms")) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val sender = parts.firstOrNull()?.displayOriginatingAddress ?: ""
        val body = parts.joinToString("") { it.displayMessageBody ?: "" }
        Scanner.scan(c.applicationContext, body, "sms", sender)
    }
}

/** Reads message notifications from WhatsApp, Telegram, Gmail etc. */
class NotifListener : NotificationListenerService() {
    private val apps = mapOf(
        "com.whatsapp" to "WhatsApp", "com.whatsapp.w4b" to "WhatsApp Business",
        "org.telegram.messenger" to "Telegram", "com.google.android.gm" to "Gmail",
        "com.instagram.android" to "Instagram", "com.facebook.orca" to "Messenger",
        "com.truecaller" to "Truecaller", "com.google.android.apps.messaging" to "Messages",
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = apps[sbn.packageName] ?: return
        if (!Repo.scope(this, "notifications")) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        if (text.matches(Regex("\\d+ new messages?.*"))) return // WhatsApp summary lines
        Scanner.scan(applicationContext, text, app.lowercase(), "$title ($app)")
    }
}
