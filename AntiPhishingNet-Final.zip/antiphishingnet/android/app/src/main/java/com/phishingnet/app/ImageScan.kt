package com.phishingnet.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

// ======================= On-device vision (Google ML Kit, offline) =======================
object Vision {
    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val hindi by lazy { TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()) }
    private val qr by lazy {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }

    /** OCR: runs the Hindi (Devanagari+Latin) model, falls back to the Latin model. */
    fun readText(img: InputImage, done: (String?, String?) -> Unit) {
        hindi.process(img).addOnSuccessListener { h ->
            if (Regex("[\\u0900-\\u097F]").containsMatchIn(h.text)) done(h.text, null)
            else latin.process(img).addOnSuccessListener { l -> done(l.text.ifBlank { h.text }, null) }
                .addOnFailureListener { done(h.text, null) }
        }.addOnFailureListener { e ->
            latin.process(img).addOnSuccessListener { done(it.text, null) }.addOnFailureListener { done(null, e.message) }
        }
    }

    fun readQr(img: InputImage, done: (List<String>, String?) -> Unit) {
        qr.process(img).addOnSuccessListener { list -> done(list.mapNotNull { it.rawValue }, null) }
            .addOnFailureListener { done(emptyList(), it.message) }
    }

    fun load(c: Context, uri: Uri): Bitmap =
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.contentResolver, uri)) { d, _, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
}

// ======================= UPI QR analysis (local, instant) =======================
/**
 * Most common QR scam in India: "Scan this QR to RECEIVE your refund / payment".
 * A UPI QR can only SEND money from you. Any QR with a preset amount, or one shared by a
 * stranger promising money, is a red flag.
 */
fun analyzeUpi(raw: String): JSONObject? {
    if (!raw.lowercase().startsWith("upi://")) return null
    val uri = Uri.parse(raw)
    val pa = uri.getQueryParameter("pa") ?: ""
    val pn = uri.getQueryParameter("pn") ?: ""
    val am = uri.getQueryParameter("am")
    val note = uri.getQueryParameter("tn") ?: ""
    val reasons = mutableListOf<String>()
    var score = 25
    reasons += "This is a UPI PAYMENT QR — scanning it SENDS money from your account, it can never give you money"
    if (!am.isNullOrBlank()) { score += 40; reasons += "Amount ₹$am is pre-filled — you would pay ₹$am to '$pn'" }
    if (Regex("refund|cashback|prize|reward|receive|kyc|lottery|winner|gift", RegexOption.IGNORE_CASE).containsMatchIn("$note $pn")) {
        score += 30; reasons += "Note says '$note' — 'scan to receive' is a well-known scam"
    }
    if (Regex("\\d{10}@").containsMatchIn(pa)) { score += 10; reasons += "Payee is a personal mobile UPI ID ($pa), not a registered merchant" }
    score = score.coerceAtMost(100)
    val verdict = if (score > 70) "Phishing" else if (score > 40) "Suspicious" else "Safe"
    return JSONObject().put("verdict", verdict).put("risk_score", score)
        .put("reasons_localized", JSONArray(reasons)).put("urls_found", JSONArray())
        .put("language", "en-IN").put("upi", JSONObject().put("pa", pa).put("pn", pn).put("am", am ?: "").put("tn", note))
}

// ======================= Screen =======================
/** mode = "ocr" (screenshot of a message) or "qr" (QR code). */
@Composable
fun ImageScanScreen(mode: String, initialUri: Uri?, onBack: () -> Unit, open: (QItem) -> Unit) {
    val c = LocalContext.current
    val activity = c as MainActivity
    val isQr = mode == "qr"
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var extracted by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<JSONObject?>(null) }
    var saved by remember { mutableStateOf<QItem?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun finish(text: String, j: JSONObject) {
        result = j; busy = false; status = null
        Repo.incStat(c, "scanned")
        val src = if (isQr) "qr" else "image"
        Repo.addHistory(c, text, j.getString("verdict"), j.getInt("risk_score"), src)
        if (j.getString("verdict") != "Safe") {
            val q = QItem(UUID.randomUUID().toString(), text, if (isQr) "QR code" else "Screenshot", src, j.getString("verdict"),
                j.getInt("risk_score"), j.getJSONArray("reasons_localized").toList(), j.getJSONArray("urls_found").toList(), System.currentTimeMillis())
            Repo.addQ(c, q); Repo.incStat(c, "blocked"); Repo.bg { runCatching { Repo.syncQ(c, q) } }
            saved = q
        }
    }

    fun serverCheck(text: String) {
        status = "Checking with Phishing Net…"
        Repo.bg {
            val r = runCatching { Repo.check(c, text, if (isQr) "qr" else "image") }
            activity.runOnUiThread {
                r.onSuccess { finish(text, it) }.onFailure { busy = false; status = "Can't reach server. Check Settings → Server URL" }
            }
        }
    }

    fun process(bmp: Bitmap) {
        bitmap = bmp; result = null; extracted = null; saved = null; busy = true
        val img = InputImage.fromBitmap(bmp, 0)
        // Always look for a QR first (a shared "screenshot" may really be a QR); otherwise read the text.
        status = "Looking for a QR code…"
        Vision.readQr(img) { codes, _ ->
            val code = codes.firstOrNull()
            if (code != null) {
                extracted = code
                val upi = analyzeUpi(code)
                if (upi != null) finish(code, upi) else serverCheck(code)
            } else if (isQr) {
                busy = false; status = "No QR code found. Try a clearer, closer photo."
            } else {
                status = "Reading text from image…"
                Vision.readText(img) { text, err ->
                    if (text.isNullOrBlank()) { busy = false; status = err ?: "No text found in this image."; return@readText }
                    extracted = text.trim()
                    serverCheck(text.trim())
                }
            }
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { runCatching { process(Vision.load(c, it)) }.onFailure { e -> status = "Couldn't open image: ${e.message}" } }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp -> bmp?.let { process(it) } }
    LaunchedEffect(initialUri) {
        initialUri?.let { u ->
            runCatching { process(Vision.load(c, u)) }.onFailure { e ->
                android.util.Log.e("PhishingNet", "shared image failed", e); status = "Couldn't open shared image: ${e.message}"
            }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(Icons.AutoMirrored.Filled.ArrowBack, onBack); Spacer(Modifier.width(12.dp))
            Column {
                Text(if (isQr) "Scan QR Code" else "Scan Screenshot", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(if (isQr) "Catch fake UPI & phishing QR codes" else "Read text from a photo of any message", color = Muted, fontSize = 13.sp)
            }
        }

        // Image preview / placeholder
        Box(Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(24.dp)).background(CardC), contentAlignment = Alignment.Center) {
            val b = bitmap
            if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconBubble(if (isQr) Icons.Outlined.QrCode2 else Icons.Outlined.Image, Blue, BlueSoft, 88.dp)
                Spacer(Modifier.height(12.dp))
                Text(if (isQr) "Pick a photo or screenshot of a QR code" else "Pick a screenshot of an SMS / WhatsApp message", color = Muted, fontSize = 14.sp)
            }
            if (busy) Box(Modifier.matchParentSize().background(Color.White.copy(alpha = .6f)), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PickBtn(Icons.Outlined.PhotoLibrary, "Gallery", Modifier.weight(1f)) {
                gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            PickBtn(Icons.Outlined.PhotoCamera, "Camera", Modifier.weight(1f)) { camera.launch(null) }
        }

        status?.let { s ->
            Row(Modifier.fillMaxWidth().background(BlueSoft, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Info, null, tint = Blue, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(s, color = Ink, fontSize = 14.sp)
            }
        }

        extracted?.let { t ->
            WhiteCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (isQr) Icons.Outlined.QrCode2 else Icons.Outlined.TextSnippet, null, tint = Muted, modifier = Modifier.size(18.dp))
                    Text(if (isQr) "  QR contains" else "  Text found in image", color = Muted, fontSize = 13.sp)
                }
                Text(t, raw = true, color = Ink, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().background(Bg, RoundedCornerShape(12.dp)).padding(12.dp))
            }
        }

        result?.let { j -> VerdictCard(j) }
        result?.optJSONObject("upi")?.let { u -> UpiCard(u) }
        saved?.let { q ->
            BlueButton("View details & report") { open(q) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun PickBtn(icon: ImageVector, label: String, m: Modifier, onClick: () -> Unit) {
    Row(m.height(56.dp).clip(RoundedCornerShape(16.dp)).background(CardC).clickable { onClick() }, verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Blue); Spacer(Modifier.width(8.dp)); Text(label, color = Ink, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun VerdictCard(j: JSONObject) {
    val v = j.getString("verdict"); val score = j.getInt("risk_score"); val col = verdictColor(v)
    val reasons = j.getJSONArray("reasons_localized").toList()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(verdictSoft(v)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (v == "Safe") Icons.Outlined.VerifiedUser else Icons.Outlined.GppBad, null, tint = col, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (v == "Safe") "Looks safe" else riskLabel(v), color = col, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("Risk score $score / 100", color = Ink.copy(alpha = .7f))
            }
        }
        reasons.forEach { Text("• $it", color = Ink, fontSize = 14.sp) }
        SpeakButton(v, score, reasons)
    }
}

@Composable
fun UpiCard(u: JSONObject) {
    WhiteCard {
        Text("UPI payment details", fontWeight = FontWeight.SemiBold, color = Ink)
        listOf("Pays to" to u.optString("pn").ifBlank { "Unknown" }, "UPI ID" to u.optString("pa"),
            "Amount" to (u.optString("am").takeIf { it.isNotBlank() }?.let { "₹$it" } ?: "Not set"),
            "Note" to u.optString("tn").ifBlank { "—" }).forEach { (k, v) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) { Text(k, color = Muted, modifier = Modifier.width(90.dp)); Text(v, raw = true, color = Ink, fontWeight = FontWeight.Medium) }
        }
        Text("💡 You never need to scan a QR or enter your UPI PIN to RECEIVE money.", color = HighC, fontSize = 13.sp)
    }
}
