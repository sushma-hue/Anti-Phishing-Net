package com.phishingnet.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** One quarantined message. Original text stays ON THE DEVICE only (never synced). */
data class QItem(
    val id: String, val text: String, val sender: String, val source: String,
    val verdict: String, val score: Int, val reasons: List<String>, val urls: List<String>,
    val ts: Long, var status: String = "quarantined",
) {
    fun toJson() = JSONObject().put("id", id).put("text", text).put("sender", sender).put("source", source)
        .put("verdict", verdict).put("score", score).put("reasons", JSONArray(reasons))
        .put("urls", JSONArray(urls)).put("ts", ts).put("status", status)

    companion object {
        fun from(o: JSONObject) = QItem(
            o.getString("id"), o.getString("text"), o.optString("sender"), o.optString("source"),
            o.getString("verdict"), o.getInt("score"), o.getJSONArray("reasons").toList(),
            o.optJSONArray("urls")?.toList() ?: emptyList(), o.getLong("ts"), o.optString("status", "quarantined"),
        )
    }
}

fun JSONArray.toList() = (0 until length()).map { getString(it) }

/** Local storage (SharedPreferences) + calls to the validation server. */
object Repo {
    private const val P = "phishingnet"
    private fun prefs(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    // ---------- settings ----------
    fun userId(c: Context): String = prefs(c).getString("uid", null)
        ?: UUID.randomUUID().toString().also { prefs(c).edit().putString("uid", it).apply() }

    // Emulator reaches the laptop at 10.0.2.2; on a real phone set the laptop IP / ngrok URL in Settings
    private val isEmulator = android.os.Build.FINGERPRINT.contains("generic") || android.os.Build.MODEL.contains("sdk", true)
    fun serverUrl(c: Context) = prefs(c).getString("server",
        "https://phishing-net.onrender.com")!!.trimEnd('/')
    fun setServerUrl(c: Context, v: String) = prefs(c).edit().putString("server", v.trim()).apply()
    fun hasConsent(c: Context) = prefs(c).getBoolean("consent", false)
    fun scope(c: Context, s: String) = prefs(c).getBoolean("scope_$s", false)
    fun setScope(c: Context, s: String, on: Boolean) = prefs(c).edit().putBoolean("scope_$s", on).apply()
    fun language(c: Context) = prefs(c).getString("lang", "auto")!!
    fun setLanguage(c: Context, v: String) = prefs(c).edit().putString("lang", v).apply()

    fun incStat(c: Context, key: String) = prefs(c).edit().putInt(key, prefs(c).getInt(key, 0) + 1).apply()
    fun stat(c: Context, key: String) = prefs(c).getInt(key, 0)

    fun setupDone(c: Context) = prefs(c).getBoolean("setup_done", false)
    fun setSetupDone(c: Context) = prefs(c).edit().putBoolean("setup_done", true).apply()

    // ---------- trusted family contact ----------
    fun family(c: Context) = prefs(c).getString("family", "")!!
    fun setFamily(c: Context, v: String) = prefs(c).edit().putString("family", v.trim()).apply()
    fun autoFamily(c: Context) = prefs(c).getBoolean("auto_family", false)
    fun setAutoFamily(c: Context, on: Boolean) = prefs(c).edit().putBoolean("auto_family", on).apply()
    /** Daily counter so a flood of scams can't spam the family member. */
    fun famSentToday(c: Context): Int {
        val day = System.currentTimeMillis() / 86_400_000
        return if (prefs(c).getLong("fam_day", -1) == day) prefs(c).getInt("fam_n", 0) else 0
    }
    fun incFamSent(c: Context) {
        val day = System.currentTimeMillis() / 86_400_000
        prefs(c).edit().putLong("fam_day", day).putInt("fam_n", famSentToday(c) + 1).apply()
    }

    // ---------- scan history (every check, incl. safe; stays on device) ----------
    fun addHistory(c: Context, text: String, verdict: String, score: Int, source: String) {
        val arr = JSONArray(prefs(c).getString("h", "[]"))
        val out = JSONArray().put(JSONObject().put("t", text.take(140)).put("v", verdict).put("s", score)
            .put("src", source).put("ts", System.currentTimeMillis()))
        for (i in 0 until minOf(arr.length(), 199)) out.put(arr.get(i))
        prefs(c).edit().putString("h", out.toString()).apply()
    }
    fun clearHistory(c: Context) = prefs(c).edit().remove("h").apply()
    fun history(c: Context): List<JSONObject> {
        val arr = JSONArray(prefs(c).getString("h", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    // ---------- quarantine ----------
    fun quarantine(c: Context): List<QItem> {
        val arr = JSONArray(prefs(c).getString("q", "[]"))
        return (0 until arr.length()).map { QItem.from(arr.getJSONObject(it)) }.sortedByDescending { it.ts }
    }

    private fun saveQ(c: Context, list: List<QItem>) =
        prefs(c).edit().putString("q", JSONArray(list.map { it.toJson() }).toString()).apply()

    fun addQ(c: Context, item: QItem) = saveQ(c, listOf(item) + quarantine(c).filter { it.id != item.id })
    fun setStatus(c: Context, id: String, status: String) {
        saveQ(c, quarantine(c).map { if (it.id == id) it.copy(status = status) else it })
        quarantine(c).find { it.id == id }?.let { bg { syncQ(c, it) } }
    }
    // read / unread (stored separately so old items keep working)
    private fun readIds(c: Context) = prefs(c).getStringSet("read", emptySet())!!
    fun isRead(c: Context, id: String) = id in readIds(c)
    fun markRead(c: Context, id: String) = prefs(c).edit().putStringSet("read", readIds(c) + id).apply()
    fun markAllRead(c: Context) = prefs(c).edit().putStringSet("read", quarantine(c).map { it.id }.toSet()).apply()
    fun unreadCount(c: Context) = quarantine(c).count { it.status == "quarantined" && !isRead(c, it.id) }
    fun clearAllQ(c: Context) { quarantine(c).forEach { removeQ(c, it.id) } }

    fun removeQ(c: Context, id: String) {
        quarantine(c).find { it.id == id }?.let { bg { syncQ(c, it.copy(status = "removed")) } }
        saveQ(c, quarantine(c).filter { it.id != id })
    }

    // ---------- network ----------
    fun bg(block: () -> Unit) = Thread { runCatching(block).onFailure { it.printStackTrace() } }.start()

    /** Sarvam UI translation via our server (fallback for languages ML Kit can't do on-device). */
    fun translateBatch(c: Context, texts: List<String>, target: String): List<String> {
        val r = http(c, "POST", "/translate", JSONObject().put("texts", JSONArray(texts)).put("target", target))
        return r.getJSONArray("texts").toList()
    }

    private fun http(c: Context, method: String, path: String, body: JSONObject? = null): JSONObject {
        val conn = URL(serverUrl(c) + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 20000; conn.readTimeout = 70000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("ngrok-skip-browser-warning", "1")
        if (body != null) { conn.doOutput = true; conn.outputStream.use { it.write(body.toString().toByteArray()) } }
        val text = (if (conn.responseCode < 400) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (conn.responseCode >= 400) error("HTTP ${conn.responseCode}: $text")
        return JSONObject(text)
    }

    /** POST /check. Blocking - call from a background thread. */
    fun check(c: Context, text: String, source: String): JSONObject {
        val body = JSONObject().put("text", text).put("source", source).put("user_id", userId(c))
        val lang = language(c)
        if (lang != "auto") body.put("reply_language", lang)
        return http(c, "POST", "/check", body)
    }

    fun recordConsent(c: Context, scopes: List<String>, granted: Boolean) {
        prefs(c).edit().putBoolean("consent", granted).apply()
        bg { http(c, "POST", "/consent", JSONObject().put("user_id", userId(c)).put("scopes", JSONArray(scopes)).put("granted", granted)) }
    }

    fun syncQ(c: Context, q: QItem) = http(c, "POST", "/quarantine", JSONObject()
        .put("user_id", userId(c)).put("verdict", q.verdict).put("risk_score", q.score)
        .put("reasons", JSONArray(q.reasons)).put("urls_found", JSONArray(q.urls)).put("status", q.status))

    fun report(c: Context, q: QItem) = bg {
        http(c, "POST", "/report", JSONObject().put("user_id", userId(c)).put("urls", JSONArray(q.urls)).put("category", "phishing"))
    }

    /** Consent withdrawal + erase everything (DPDP Act). */
    fun deleteAll(c: Context) {
        val uid = userId(c)
        bg { http(c, "DELETE", "/user/$uid") }
        prefs(c).edit().clear().apply()
    }

    fun ping(c: Context): Boolean = runCatching { http(c, "GET", "/health").optString("status") == "ok" }.getOrDefault(false)
}
