@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
package com.phishingnet.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.Locale

// ======================= Read aloud (Android TTS, for senior citizens) =======================
/**
 * Text-to-speech with a proper Stop.
 * - Voice language is picked from the SCRIPT of the text (Kannada text -> Kannada voice, English -> en-IN),
 *   so we never ask a Kannada voice to read English.
 * - If the phone has no voice for that script, we fall back to an English summary instead of silence.
 * - [speakingId] is Compose state, so every Read-aloud button can flip to "Stop".
 */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: Triple<String, String, String>? = null
    private var onEnd: (() -> Unit)? = null
    val speakingId = mutableStateOf<String?>(null)

    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    fun isSpeaking(id: String) = speakingId.value == id

    fun toggle(c: Context, id: String, text: String, fallback: String, end: (() -> Unit)? = null) {
        if (isSpeaking(id)) stop() else speak(c, id, text, fallback, end)
    }

    fun speak(c: Context, id: String, text: String, fallback: String, end: (() -> Unit)? = null) {
        val t = tts
        if (t == null || !ready) {
            pending = Triple(id, text, fallback); onEnd = end
            if (t == null) tts = TextToSpeech(c.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(u: String?) {}
                        override fun onDone(u: String?) = finished()
                        @Deprecated("Deprecated in Java") override fun onError(u: String?) = finished()
                        override fun onStop(u: String?, interrupted: Boolean) = finished()
                    })
                    pending?.let { (i, x, f) -> pending = null; speak(c, i, x, f, onEnd) }
                } else main.post { android.widget.Toast.makeText(c, "Text-to-speech is not available on this phone", android.widget.Toast.LENGTH_LONG).show() }
            }
            return
        }
        t.stop()
        val loc = localeFor(text)
        var say = text
        if (t.setLanguage(loc) < TextToSpeech.LANG_AVAILABLE) {
            // No voice for this language: speak the English version instead of staying silent
            if (t.setLanguage(Locale("en", "IN")) < TextToSpeech.LANG_AVAILABLE) t.setLanguage(Locale.US)
            say = fallback
            if (loc.language != "en") main.post {
                android.widget.Toast.makeText(c, "${loc.displayLanguage} voice not installed — reading in English", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        t.setSpeechRate(0.9f) // a little slower: clearer for senior citizens
        onEnd = end
        speakingId.value = id
        t.speak(clean(say), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() { tts?.stop(); finished() }

    private fun finished() { main.post { speakingId.value = null; onEnd?.invoke(); onEnd = null } }

    private fun localeFor(text: String): Locale {
        val code = sarvamScript(text)
        return Locale.forLanguageTag(code)
    }

    /** Same Unicode-block trick the server uses: which Indian script is this text in? */
    private fun sarvamScript(text: String): String {
        val counts = mutableMapOf<String, Int>()
        for (ch in text) {
            val code = when (ch.code) {
                in 0x0900..0x097F -> "hi-IN"; in 0x0980..0x09FF -> "bn-IN"; in 0x0A80..0x0AFF -> "gu-IN"
                in 0x0B80..0x0BFF -> "ta-IN"; in 0x0C00..0x0C7F -> "te-IN"; in 0x0C80..0x0CFF -> "kn-IN"
                in 0x0D00..0x0D7F -> "ml-IN"; else -> null
            } ?: continue
            counts[code] = (counts[code] ?: 0) + 1
        }
        return counts.maxByOrNull { it.value }?.key ?: "en-IN"
    }

    /** Make text sound natural: no raw links, symbols or "OTP" read as a word. */
    private fun clean(s: String) = s
        .replace(Regex("(https?://|www\\.)\\S+|\\b[a-z0-9-]+\\.(com|in|xyz|top|shop|info|ly|online|site|link|click)\\S*", RegexOption.IGNORE_CASE), "a link")
        .replace("/100", " out of 100").replace("·", ",").replace("•", "").replace("—", ",")
        .replace("₹", " rupees ").replace(Regex("\\bOTP\\b"), "O T P").replace(Regex("\\bKYC\\b"), "K Y C")
        .replace(Regex("\\bPAN\\b"), "pan card").replace(Regex("\\bUPI\\b"), "U P I").replace(Regex("[\"'“”‘’]"), "")
}

/** What we say out loud. Kept short, calm and clear. */
fun spokenVerdict(verdict: String, score: Int, reasons: List<String>): String {
    val r = reasons.filter { it != "No phishing signals found" }.take(3)
    val why = if (r.isEmpty()) "" else " Here is why. " + r.mapIndexed { i, s -> "${listOf("One", "Two", "Three")[i]}: ${s.trimEnd('.')}." }.joinToString(" ")
    return when (verdict) {
        "Safe" -> "Phishing Net. This message looks safe. We found no warning signs. Still, never share your OTP or PIN with anyone."
        "Suspicious" -> "Phishing Net caution. This message looks suspicious. Medium risk, $score out of 100.$why " +
            "Please do not click any link, do not call back, and never share your OTP or PIN."
        else -> "Phishing Net warning! This message is a scam. High risk, $score out of 100.$why " +
            "Do not click any link, do not call back, do not pay, and never share your OTP or PIN."
    }
}

/** English-only version used when the phone has no voice for the reasons' language. */
fun spokenFallback(verdict: String, score: Int) = spokenVerdict(verdict, score, emptyList())

// ======================= Warn a family member =======================
fun warnFamily(c: Context, q: QItem) {
    val safeText = q.text.replace(Regex("(https?://\\S+|www\\.\\S+|\\b[\\w-]+\\.(com|in|xyz|top|shop|info|ly|online|site|link|click)\\S*)", RegexOption.IGNORE_CASE), "[link removed]")
    val msg = "⚠️ Phishing Net alert: I received a ${riskLabel(q.verdict)} message (risk ${q.score}/100):\n\"${safeText.take(160)}\"\n" +
        "Please don't click such links or share OTP. Report: 1930 / cybercrime.gov.in"
    val num = Repo.family(c).filter { it.isDigit() }
    val intent = if (num.length >= 10) {
        val full = if (num.length == 10) "91$num" else num
        Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$full?text=${Uri.encode(msg)}"))
    } else Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Warn family")
    c.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

// ======================= Brand: "PN | PHISHING NET" lockup =======================
private val BrandPink = Color(0xFFEC4899)

/** Serif PN monogram tile + thin divider + PHISHING **NET** (Karma-style lockup). */
@Composable
fun LogoLockup(modifier: Modifier = Modifier, tile: androidx.compose.ui.unit.Dp = 36.dp) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ic_pn_logo), "Phishing Net", Modifier.size(tile).clip(RoundedCornerShape(tile * 0.22f)))
        Spacer(Modifier.width(12.dp))
        Box(Modifier.width(1.dp).height(tile * 0.8f).background(Color(0xFFD1D5DB)))
        Spacer(Modifier.width(12.dp))
        androidx.compose.material3.Text(androidx.compose.ui.text.buildAnnotatedString {
            append("PHISHING ")
            pushStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Bold, color = BrandPink)); append("NET"); pop()
        }, color = Ink, fontSize = 16.sp, letterSpacing = 1.5.sp)
    }
}

/** Big serif PN with the violet->pink gradient (splash / consent). */
@Composable
fun BrandMark(size: androidx.compose.ui.unit.Dp = 96.dp) {
    Image(painterResource(R.drawable.ic_pn_logo), "Phishing Net", Modifier.size(size).clip(RoundedCornerShape(size * 0.22f)))
}

// ======================= Onboarding slides =======================
data class Slide(val icon: ImageVector, val title: String, val body: String, val tint: Color, val bg: Color)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val slides = listOf(
        Slide(Icons.Outlined.GppMaybe, "Scams look real", "Fake KYC, electricity, parcel and lottery messages trick lakhs of Indians every day.", HighC, HighSoft),
        Slide(Icons.Outlined.Radar, "We watch for you", "Phishing Net checks your SMS and WhatsApp messages and warns you before you click.", Blue, BlueSoft),
        Slide(Icons.Outlined.Translate, "In your language", "Get warnings in ಕನ್ನಡ, हिंदी, தமிழ், తెలుగు and more — even read aloud.", SafeC, SafeSoft),
    )
    var i by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            LogoLockup(Modifier.weight(1f), 32.dp)
            Text("Skip", color = Muted, modifier = Modifier.clickable { onDone() }.padding(8.dp))
        }
        Spacer(Modifier.weight(1f))
        AnimatedContent(i, label = "slide") { idx ->
            val s = slides[idx]
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(220.dp).background(s.bg, CircleShape), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(150.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(s.icon, null, tint = s.tint, modifier = Modifier.size(80.dp))
                    }
                }
                Spacer(Modifier.height(36.dp))
                Text(s.title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text(s.body, fontSize = 16.sp, color = Muted, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 24.dp)) {
            slides.indices.forEach { d ->
                val w by animateFloatAsState(if (d == i) 28f else 8f, label = "dot")
                Box(Modifier.height(8.dp).width(w.dp).background(if (d == i) Blue else Line, RoundedCornerShape(4.dp)))
            }
        }
        BlueButton(if (i == slides.lastIndex) "Get started" else "Next") { if (i < slides.lastIndex) i++ else onDone() }
    }
}

// ======================= Home extras =======================
@Composable
fun QuickActions(onPaste: () -> Unit, onHistory: () -> Unit, onImage: () -> Unit, onQr: () -> Unit) {
    val actions = listOf(
        Triple(Icons.Outlined.Image, "Scan\nScreenshot", onImage),
        Triple(Icons.Outlined.QrCodeScanner, "Scan\nQR Code", onQr),
        Triple(Icons.Outlined.ContentPaste, "Paste &\nScan", onPaste),
        Triple(Icons.Outlined.History, "History", onHistory),
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        actions.forEach { (icon, label, action) ->
            Column(Modifier.clip(RoundedCornerShape(16.dp)).clickable { action() }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(60.dp).background(CardC, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = Blue, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.height(6.dp))
                Text(label, fontSize = 12.sp, color = Color(0xFF4B5563), textAlign = TextAlign.Center, lineHeight = 14.sp)
            }
        }
    }
}

/** 7-day bar chart of scans: grey = safe, red = threats. */
@Composable
fun WeeklyActivity() {
    val c = LocalContext.current
    val hist = Repo.history(c)
    val cal = Calendar.getInstance()
    val days = (6 downTo 0).map { back ->
        val d = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -back); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
        val start = d.timeInMillis; val end = start + 86_400_000
        val items = hist.filter { it.getLong("ts") in start until end }
        Triple(d.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, Locale.ENGLISH)!!.take(1),
            items.count { it.getString("v") == "Safe" }, items.count { it.getString("v") != "Safe" })
    }
    val max = maxOf(1, days.maxOf { it.second + it.third })
    val total = hist.size; val threats = hist.count { it.getString("v") != "Safe" }
    WhiteCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("This Week", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.weight(1f))
            Legend(Color(0xFFCBD5E1), "Safe"); Spacer(Modifier.width(10.dp)); Legend(HighC, "Threats")
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            days.forEachIndexed { idx, (label, safe, bad) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val h = 100f
                    Column(Modifier.width(22.dp).height(h.dp), verticalArrangement = Arrangement.Bottom) {
                        if (bad > 0) Box(Modifier.fillMaxWidth().height((h * bad / max).dp).background(HighC, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = if (safe == 0) 6.dp else 0.dp, bottomEnd = if (safe == 0) 6.dp else 0.dp)))
                        if (safe > 0) Box(Modifier.fillMaxWidth().height((h * safe / max).dp).background(Color(0xFFCBD5E1), RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp, topStart = if (bad == 0) 6.dp else 0.dp, topEnd = if (bad == 0) 6.dp else 0.dp)))
                        if (safe + bad == 0) Box(Modifier.fillMaxWidth().height(4.dp).background(Line, RoundedCornerShape(2.dp)))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(label, fontSize = 12.sp, color = if (idx == 6) Blue else Muted, fontWeight = if (idx == 6) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().background(Bg, RoundedCornerShape(12.dp)).padding(12.dp)) {
            StatCol("$total", "Total checks", Modifier.weight(1f))
            StatCol("$threats", "Scams caught", Modifier.weight(1f))
            StatCol(if (total == 0) "–" else "${100 * (total - threats) / total}%", "Clean rate", Modifier.weight(1f))
        }
    }
}

@Composable
fun Legend(color: Color, label: String) {
    Box(Modifier.size(8.dp).background(color, CircleShape)); Spacer(Modifier.width(4.dp))
    Text(label, fontSize = 12.sp, color = Muted)
}

data class Trend(
    val title: String, val tag: String, val example: String, val icon: ImageVector, val c1: Color, val c2: Color,
    val how: String, val flags: List<String>, val todo: List<String>,
)

val TRENDS = listOf(
    Trend("Electricity bill scam", "🔥 Trending", "Dear customer, your electricity will be disconnected tonight at 9:30pm. Call 9876543210 immediately.", Icons.Outlined.Bolt, Color(0xFFF59E0B), Color(0xFFEA580C),
        "Scammers pretend to be from the electricity board and threaten to cut your power tonight. When you call, they ask you to install a 'support' app (AnyDesk, TeamViewer) or pay a small fee, then empty your bank account.",
        listOf("Threat of disconnection 'tonight' or within hours", "Asks you to call a personal mobile number", "Asks you to install a screen-sharing app", "Sent from a normal 10-digit number, not the board"),
        listOf("Never call the number in the SMS", "Check your bill only on the official board website or app", "Never install AnyDesk / TeamViewer on a stranger's request")),
    Trend("Fake KYC update", "🏦 Banking", "Your SBI KYC expired, update now: bit.ly/xyz", Icons.Outlined.AccountBalance, Color(0xFF3B82F6), Color(0xFF1D4ED8),
        "You get a message saying your bank KYC, PAN or Aadhaar link has expired and your account will be blocked. The link opens a fake bank page that steals your login, card details and OTP.",
        listOf("Short links like bit.ly or tinyurl", "Says your account will be blocked or frozen", "Asks for OTP, PIN, card number or net-banking password", "Website name is slightly different from the real bank"),
        listOf("Banks never ask for KYC through SMS links", "Visit your branch or type the bank's website yourself", "Never share OTP, not even with 'bank staff'")),
    Trend("Parcel held scam", "📦 Courier", "ನಿಮ್ಮ ಪಾರ್ಸೆಲ್ ಹಿಡಿಯಲಾಗಿದೆ, ₹50 ಕಟ್ಟಿ", Icons.Outlined.LocalShipping, Color(0xFF8B5CF6), Color(0xFF6D28D9),
        "A message, often in your own language, says a parcel is stuck and you must pay a small fee like ₹50. The payment page steals your card details. Some versions claim police found drugs in your parcel.",
        listOf("Small 'redelivery' or 'customs' fee", "You weren't expecting any parcel", "Payment link isn't the courier's real website", "Threats of police or legal action"),
        listOf("Track parcels only in the courier's official app", "Real police never demand money over phone or video call", "Ignore and delete the message")),
    Trend("Look-alike shopping", "🛒 Shopping", "Big Diwali sale! http://amaz0n-offer.xyz", Icons.Outlined.ShoppingBag, Color(0xFFEC4899), Color(0xFFBE185D),
        "Fake websites copy big brands with a tiny spelling change (amaz0n, flipkartt) and show huge festival discounts. You pay, nothing arrives, and your card details are stolen.",
        listOf("Spelling tricks: 0 instead of o, extra letters", "Strange endings like .xyz, .top, .shop", "Prices too good to be true (90% off)", "Only UPI or card payment, no cash on delivery"),
        listOf("Open shopping apps directly, not from links", "Check the website name letter by letter", "Scan any deal link with Phishing Net first")),
    Trend("KBC lottery prize", "🎁 Lottery", "Congratulations! You won ₹25,00,000 in KBC lottery. Click here to claim: http://kbc-prize.top", Icons.Outlined.Redeem, Color(0xFF10B981), Color(0xFF047857),
        "You're told you won a huge prize from KBC, a bank or a company. To 'release' the money you must first pay tax or processing fees. The fees keep growing and the prize never comes.",
        listOf("You never entered any lottery", "Asks you to pay to receive money", "Uses famous names or photos (KBC, celebrities)", "Pressure to claim quickly"),
        listOf("Real prizes never ask for fees upfront", "Don't share bank details or Aadhaar", "Report at cybercrime.gov.in or call 1930")),
)

/** Horizontal carousel; tapping a card opens an explainer about that scam. */
@Composable
fun TrendingScams(onTry: (String) -> Unit) {
    var open by remember { mutableStateOf<Trend?>(null) }
    open?.let { t -> TrendInfo(t, onClose = { open = null }, onTry = { open = null; onTry(t.example) }) }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 20.dp, bottom = 10.dp)) {
            Text("Trending Scams", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.weight(1f))
            Text("Tap to learn", fontSize = 13.sp, color = Blue)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TRENDS.forEach { t ->
                Column(
                    Modifier.width(230.dp).height(150.dp).clip(RoundedCornerShape(22.dp))
                        .background(Brush.linearGradient(listOf(t.c1, t.c2))).clickable { open = t }.padding(16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(Color.White.copy(alpha = .22f), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(t.icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.weight(1f))
                        Text(t.tag, color = Color.White, fontSize = 11.sp, modifier = Modifier.background(Color.White.copy(alpha = .22f), RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Text(t.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("“${t.example}”", color = Color.White.copy(alpha = .85f), fontSize = 12.sp, maxLines = 2, raw = true, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

/** Explainer popup: how the scam works, red flags, what to do. */
@Composable
fun TrendInfo(t: Trend, onClose: () -> Unit, onTry: () -> Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(28.dp)).background(Color.White)
            .verticalScroll(rememberScrollState())) {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(t.c1, t.c2))).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Color.White.copy(alpha = .22f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(t.icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Text(t.tag, color = Color.White, fontSize = 12.sp, modifier = Modifier.background(Color.White.copy(alpha = .22f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))
                }
                Spacer(Modifier.height(12.dp))
                Text(t.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            }
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("How it works", fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 16.sp)
                Text(t.how, color = Color(0xFF4B5563), fontSize = 14.sp)
                Text("Example message", fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 16.sp)
                Text("“${t.example}”", color = Ink, fontSize = 14.sp, raw = true,
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFF3F6FB), RoundedCornerShape(14.dp)).padding(12.dp))
                Text("🚩 Red flags", fontWeight = FontWeight.SemiBold, color = Color(0xFFE5484D), fontSize = 16.sp)
                t.flags.forEach { Text("•  $it", color = Ink, fontSize = 14.sp) }
                Text("✅ What to do", fontWeight = FontWeight.SemiBold, color = Color(0xFF16A34A), fontSize = 16.sp)
                t.todo.forEach { Text("•  $it", color = Ink, fontSize = 14.sp) }
                Spacer(Modifier.height(6.dp))
                BlueButton("Test this example in scanner") { onTry() }
                Text("Close", color = Muted, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(12.dp)).clickable { onClose() }.padding(horizontal = 20.dp, vertical = 10.dp))
            }
        }
    }
}

// ======================= History screen =======================
@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val c = LocalContext.current
    var filter by remember { mutableStateOf("all") }
    var ver by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    val all = remember(ver) { Repo.history(c) }
    val items = all.filter { filter == "all" || (filter == "threat") == (it.getString("v") != "Safe") }
    if (confirm) androidx.compose.material3.AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = CardC,
        icon = { IconBubble(Icons.Outlined.DeleteSweep, HighC, HighSoft, 56.dp) },
        title = { Text("Clear scan history?", fontWeight = FontWeight.Bold) },
        text = { Text("This deletes all ${all.size} past checks and resets the weekly chart. Your alerts and original messages are not touched. This can't be undone.", color = Muted) },
        confirmButton = { androidx.compose.material3.TextButton({ Repo.clearHistory(c); ver++; confirm = false }) { Text("Clear history", color = HighC, fontWeight = FontWeight.Bold) } },
        dismissButton = { androidx.compose.material3.TextButton({ confirm = false }) { Text("Cancel", color = Muted) } },
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(Icons.AutoMirrored.Filled.ArrowBack, onBack); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text("Scan History", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink); Text("${all.size} checks · stored only on this phone", color = Muted, fontSize = 13.sp) }
            if (all.isNotEmpty()) Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { confirm = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.DeleteSweep, null, tint = HighC, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                Text("Clear", color = HighC, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 12.dp)) {
            listOf("all" to "All", "threat" to "Threats", "safe" to "Safe").forEach { (k, l) ->
                val sel = filter == k
                Text(l, color = if (sel) Color.White else Color(0xFF4B5563), fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(if (sel) Blue else CardC).clickable { filter = k }.padding(horizontal = 18.dp, vertical = 10.dp))
            }
        }
        if (items.isEmpty()) AlertRowEmpty()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(items) { h ->
                val v = h.getString("v")
                val (icon, tint, bg) = sourceIcon(h.getString("src"))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardC).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(icon, tint, bg, 42.dp); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(h.getString("t"), color = Ink, maxLines = 1, raw = true, overflow = TextOverflow.Ellipsis)
                        Text("${h.getString("src")} • ${ago(h.getLong("ts"))} • ${h.getInt("s")}/100", color = Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Pill(riskLabel(v), verdictColor(v), verdictSoft(v))
                }
            }
        }
    }
}

// ======================= Real or Scam? quiz =======================
data class QuizQ(val msg: String, val scam: Boolean, val why: String)

val QUIZ = listOf(
    QuizQ("Your SBI KYC expired, update now: bit.ly/xyz", true, "Banks never send KYC links. Short links hide the real site."),
    QuizQ("482913 is your OTP for txn of Rs 1,250 at HDFC Bank. Do not share it with anyone.", false, "Genuine OTP: no link, and it tells you NOT to share."),
    QuizQ("Electricity will be disconnected tonight, call 9876543210", true, "Boards never threaten 'tonight' with a personal mobile number."),
    QuizQ("Your Amazon order #402-118 has been shipped. Track on amazon.in/orders", false, "Official domain amazon.in, no urgency, no payment asked."),
    QuizQ("Congratulations! You won ₹25,00,000 in KBC lottery. Pay ₹999 tax to claim.", true, "You can't win a lottery you never entered. Fees = scam."),
    QuizQ("Dear user, your PAN is not linked. Account will be blocked in 24 hrs. Click http://incometax-update.xyz", true, "Fake .xyz site imitating Income Tax + 24-hour threat."),
    QuizQ("Hi! Meet at the café at 5pm?", false, "Normal personal message — no links, money or urgency."),
    QuizQ("India Post: Your parcel is held due to incomplete address. Pay ₹25 at indiapost-redelivery.top", true, "India Post's real site is indiapost.gov.in, never .top."),
)

@Composable
fun QuizScreen(onBack: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var answered by remember { mutableStateOf<Boolean?>(null) } // user's pick: true = scam
    val done = idx >= QUIZ.size
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(Icons.AutoMirrored.Filled.ArrowBack, onBack); Spacer(Modifier.width(12.dp))
            Text("Real or Scam?", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
            if (!done) Text("${idx + 1}/${QUIZ.size}", color = Muted)
        }
        if (done) {
            val pct = score * 100 / QUIZ.size
            WhiteCard {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    IconBubble(if (pct >= 75) Icons.Outlined.EmojiEvents else Icons.Outlined.School, if (pct >= 75) Color(0xFFF59E0B) else Blue, if (pct >= 75) Color(0xFFFFF4E0) else BlueSoft, 96.dp)
                }
                Text("$score / ${QUIZ.size} correct", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.align(Alignment.CenterHorizontally))
                Text(if (pct >= 75) "Scam spotter! Share this quiz with your family." else "Scammers are clever. Read the Stay Safe tips and try again.",
                    color = Muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            BlueButton("Play again") { idx = 0; score = 0; answered = null }
            return@Column
        }
        val q = QUIZ[idx]
        LinearBar((idx) / QUIZ.size.toFloat())
        // the message as a chat bubble
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 4.dp, topEnd = 22.dp, bottomEnd = 22.dp, bottomStart = 22.dp)).background(CardC).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Sms, null, tint = Muted, modifier = Modifier.size(16.dp)); Text("  New message", color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(8.dp)); Text(q.msg, fontSize = 17.sp, color = Ink, raw = true)
        }
        val pick = answered
        if (pick == null) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuizBtn("✅  Real", SafeC, SafeSoft, Modifier.weight(1f)) { answered = false; if (!q.scam) score++ }
                QuizBtn("🚨  Scam", HighC, HighSoft, Modifier.weight(1f)) { answered = true; if (q.scam) score++ }
            }
        } else {
            val right = pick == q.scam
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(if (right) SafeSoft else HighSoft).padding(18.dp)) {
                Text(if (right) "Correct! 🎉" else "Not quite 😬", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = if (right) SafeC else HighC)
                Text("This was ${if (q.scam) "a SCAM" else "REAL"}. ${q.why}", color = Ink)
            }
            BlueButton(if (idx == QUIZ.lastIndex) "See my score" else "Next question") { idx++; answered = null }
        }
    }
}

@Composable
fun QuizBtn(label: String, fg: Color, bg: Color, m: Modifier, onClick: () -> Unit) {
    Box(m.height(64.dp).clip(RoundedCornerShape(18.dp)).background(bg).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = fg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
fun LinearBar(f: Float) {
    val a by animateFloatAsState(f, tween(400), label = "bar")
    Box(Modifier.fillMaxWidth().height(8.dp).background(Line, RoundedCornerShape(4.dp))) {
        val m = Modifier.fillMaxWidth(a).fillMaxHeight()
        if (f >= 1f) Box(m.background(SafeC, RoundedCornerShape(4.dp)))
        else Box(m.background(BlueGrad, RoundedCornerShape(4.dp)))
    }
}

/** Promo card on the Learn tab that opens the quiz. */
@Composable
fun QuizPromo(onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))))
        .clickable { onOpen() }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Real or Scam?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("Test yourself with ${QUIZ.size} real Indian messages", color = Color.White.copy(alpha = .85f), fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Text("Play quiz →", color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                modifier = Modifier.background(Color.White, RoundedCornerShape(50)).padding(horizontal = 14.dp, vertical = 6.dp))
        }
        Icon(Icons.Outlined.Quiz, null, tint = Color.White, modifier = Modifier.size(64.dp))
    }
}

@Composable
fun SpeakButton(verdict: String, score: Int, reasons: List<String>) {
    val c = LocalContext.current
    val text = spokenVerdict(verdict, score, reasons)
    val id = remember(text) { "say-" + text.hashCode() }
    val speaking = Speaker.speakingId.value == id
    // stop talking if the user leaves this screen
    DisposableEffect(id) { onDispose { if (Speaker.isSpeaking(id)) Speaker.stop() } }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(if (speaking) HighSoft else BlueSoft)
            .clickable { Speaker.toggle(c, id, text, spokenFallback(verdict, score)) }.padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (speaking) Icons.Outlined.StopCircle else Icons.AutoMirrored.Outlined.VolumeUp, null,
            tint = if (speaking) HighC else Blue, modifier = Modifier.size(18.dp))
        Text(if (speaking) " Stop" else " Read aloud", color = if (speaking) HighC else Blue, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
