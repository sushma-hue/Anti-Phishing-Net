package com.phishingnet.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import java.util.Locale

/**
 * Whole-app translation.
 * - Every UI string goes through [tr] (the app's own [Text] below calls it automatically).
 * - English is the source. Strings are translated lazily the first time they appear and cached
 *   per language on the phone, so after the first pass the app works offline.
 * - On-device Google ML Kit does the work; languages it lacks (e.g. Malayalam) go to the server's Sarvam API.
 * - User content (message text, phone numbers, links) is never translated: pass raw = true or it is skipped.
 */
object I18n {
    /** Settings language code ("auto", "en-IN", "hi-IN", ...). */
    var appLang by mutableStateOf("auto"); private set
    /** Bumped whenever new translations arrive -> recomposes every [tr] reader. */
    private var version by mutableIntStateOf(0)

    private var target = "en"              // ISO code actually used ("hi", "kn", ...)
    private var cache = HashMap<String, String>()
    private val pending = LinkedHashSet<String>()
    private var translator: Translator? = null
    private var modelReady = false
    private var busy = false
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())

    private val SUPPORTED = setOf("hi", "kn", "ta", "te", "ml", "mr", "bn")
    private val INDIC = Regex("[\\u0900-\\u0DFF]")
    private val PHONE_OR_LINK = Regex("\\d{6,}|https?://|www\\.|@|\\.(com|in|xyz|top)\\b")
    // never translated inside a sentence
    private val KEEP = listOf("Phishing Net", "WhatsApp", "Telegram", "Gmail", "SMS", "OTP", "UPI", "KYC", "PAN", "Aadhaar", "QR", "PIN", "CVV", "SBI", "HDFC", "KBC")

    fun init(c: Context) {
        if (::app.isInitialized && version > 0) return // already running (e.g. receiver woke us first)
        app = c.applicationContext
        apply(Repo.language(app))
    }

    /** Called when the user picks a language in Settings. */
    fun setLanguage(c: Context, code: String) {
        Repo.setLanguage(c, code)
        apply(code)
    }

    private fun apply(code: String) {
        appLang = code
        val iso = if (code == "auto") Locale.getDefault().language else code.substringBefore('-')
        val newTarget = if (iso in SUPPORTED) iso else "en"
        if (newTarget == target && version > 0) return
        target = newTarget
        translator?.close(); translator = null; modelReady = false
        pending.clear()
        // bundled translations first (instant, offline), then anything learned on this phone
        cache = bundled(target).apply { putAll(load(target)) }
        version++
        if (target == "en") return
        val ml = TranslateLanguage.fromLanguageTag(target)
        if (ml != null) {
            translator = Translation.getClient(TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(ml).build())
            translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener { modelReady = true; pump() }
                .addOnFailureListener { // no internet for the model -> try our server (Sarvam) instead
                    it.printStackTrace(); translator?.close(); translator = null; modelReady = true; pump()
                }
        } else {
            modelReady = true // server (Sarvam) path
        }
    }

    /** Translate an English UI string into the current language (falls back to English until ready). */
    fun tr(en: String): String {
        @Suppress("UNUSED_VARIABLE") val v = version // read state -> recompose when translations land
        if (target == "en" || !worth(en)) return en
        cache[en]?.let { return it }
        if (pending.add(en)) main.post { pump() }
        return en
    }

    private val ENGLISH_ONLY = setOf("Warn family")  // shown in English in every language
    private fun worth(s: String) = s.trim() !in ENGLISH_ONLY && s.length >= 2 && s.any { it.isLetter() } &&
        !INDIC.containsMatchIn(s) && !PHONE_OR_LINK.containsMatchIn(s)

    private fun protect(s: String): String {
        var out = s
        KEEP.forEachIndexed { i, w -> out = out.replace(w, "⟦$i⟧") }
        return out
    }

    private fun restore(s: String): String {
        var out = s
        KEEP.forEachIndexed { i, w -> out = out.replace("⟦$i⟧", w).replace("⟦ $i ⟧", w) }
        return out
    }

    private fun pump() {
        if (busy || !modelReady || pending.isEmpty() || target == "en") return
        busy = true
        val lang = target
        val batch = pending.take(40)
        val t = translator
        if (t != null) {
            var left = batch.size
            batch.forEach { en ->
                t.translate(protect(en)).addOnCompleteListener { task ->
                    if (lang == target) {
                        task.result?.let { cache[en] = restore(it) }
                        pending.remove(en)
                    }
                    if (--left == 0) finishBatch(lang)
                }
            }
        } else {
            Repo.bg {
                val out = runCatching { Repo.translateBatch(app, batch.map(::protect), "$lang-IN") }.getOrNull()
                main.post {
                    if (lang == target) {
                        batch.forEachIndexed { i, en ->
                            val tx = out?.getOrNull(i)?.let(::restore)
                            if (tx != null && tx != en) cache[en] = tx
                            pending.remove(en)
                        }
                    }
                    finishBatch(lang)
                }
            }
        }
    }

    private fun finishBatch(lang: String) {
        busy = false
        if (lang == target) { save(lang); version++ }
        pump()
    }

    /** Pre-translated UI strings shipped in assets/i18n/<lang>.json. */
    private fun bundled(lang: String): HashMap<String, String> {
        val m = HashMap<String, String>()
        if (lang == "en") return m
        runCatching {
            val o = JSONObject(app.assets.open("i18n/$lang.json").bufferedReader().use { it.readText() })
            o.keys().forEach { k -> m[k] = o.getString(k) }
        }
        return m
    }

    private fun prefs() = app.getSharedPreferences("i18n", Context.MODE_PRIVATE)
    private fun load(lang: String): HashMap<String, String> {
        val m = HashMap<String, String>()
        runCatching {
            val o = JSONObject(prefs().getString(lang, "{}")!!)
            o.keys().forEach { k -> m[k] = o.getString(k) }
        }
        return m
    }
    private fun save(lang: String) {
        // store only what this phone learned (bundled strings are already in the APK)
        val base = bundled(lang)
        val learned = cache.filter { (k, v) -> base[k] != v }
        prefs().edit().putString(lang, JSONObject(learned as Map<*, *>).toString()).apply()
    }
}

fun tr(en: String) = I18n.tr(en)

/**
 * App-wide Text: same as Material3 Text but translates the string into the app language.
 * Use raw = true for user content (message bodies, numbers, links) that must stay as-is.
 */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    maxLines: Int = Int.MAX_VALUE,
    style: TextStyle = LocalTextStyle.current,
    raw: Boolean = false,
) = androidx.compose.material3.Text(
    text = if (raw) text else I18n.tr(text), modifier = modifier, color = color, fontSize = fontSize,
    fontStyle = fontStyle, fontWeight = fontWeight, fontFamily = fontFamily, letterSpacing = letterSpacing,
    textAlign = textAlign, lineHeight = lineHeight, overflow = overflow, maxLines = maxLines, style = style,
)
