@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.phishingnet.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.WindowCompat
import org.json.JSONObject
import java.util.*
import kotlin.math.cos
import kotlin.math.sin

// ---------- Theme: clean light UI, blue accent, white rounded cards ----------
val Bg = Color(0xFFF7F5FC); val CardC = Color.White; val Line = Color(0xFFECE7F6)
val Blue = Color(0xFF7C3AED); val BlueDark = Color(0xFF6D28D9); val BlueSoft = Color(0xFFF3EEFF) // brand violet (names kept to avoid churn)
val Ink = Color(0xFF111827); val Muted = Color(0xFF8A94A6)
val SafeC = Color(0xFF16A34A); val SafeSoft = Color(0xFFE7F8EE)
val MedC = Color(0xFFD97706); val MedSoft = Color(0xFFFFF4E0)
val HighC = Color(0xFFE5484D); val HighSoft = Color(0xFFFDECEC)
val BlueGrad = Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))) // logo gradient

fun verdictColor(v: String) = when (v) { "Phishing" -> HighC; "Suspicious" -> MedC; else -> SafeC }
fun verdictSoft(v: String) = when (v) { "Phishing" -> HighSoft; "Suspicious" -> MedSoft; else -> SafeSoft }
fun riskLabel(v: String) = when (v) { "Phishing" -> "High Risk"; "Suspicious" -> "Medium Risk"; else -> "Safe" }

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf<String?>(null)
    private var openId by mutableStateOf<String?>(null)
    private var sharedImage by mutableStateOf<Uri?>(null)
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        I18n.init(this)
        window.statusBarColor = Bg.toArgb()
        window.navigationBarColor = Bg.toArgb()
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true
        }
        handle(intent)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Bg, surface = CardC, onSurface = Ink)) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    App(sharedText, openId, sharedImage, onConsumed = { sharedText = null; openId = null; sharedImage = null }, askPerms = ::askPerms)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }
    override fun onResume() { super.onResume(); Scanner.appVisible = true }
    override fun onPause() { super.onPause(); Scanner.appVisible = false }

    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            if (i.type?.startsWith("image/") == true)
                sharedImage = androidx.core.content.IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
            else sharedText = i.getStringExtra(Intent.EXTRA_TEXT)
        }
        i?.getStringExtra("open_id")?.let { openId = it }
    }

    fun askPerms(sms: Boolean) {
        val p = mutableListOf<String>()
        if (sms) p += Manifest.permission.RECEIVE_SMS
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        if (p.isNotEmpty()) permLauncher.launch(p.toTypedArray())
    }
    fun askSendSms() = permLauncher.launch(arrayOf(Manifest.permission.SEND_SMS))
}

fun notifAccessGranted(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

enum class Tab(val label: String, val icon: ImageVector) {
    Scan("Scan", Icons.Outlined.DocumentScanner), Alerts("Alerts", Icons.Outlined.Shield),
    Learn("Learn", Icons.Outlined.School), Settings("Settings", Icons.Outlined.Settings)
}

@Composable
fun App(shared: String?, openId: String?, sharedImage: Uri?, onConsumed: () -> Unit, askPerms: (Boolean) -> Unit) {
    val c = LocalContext.current
    var consent by remember { mutableStateOf(Repo.hasConsent(c)) }
    var tab by remember { mutableStateOf(Tab.Scan) }
    var detail by remember { mutableStateOf<QItem?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var popup by remember { mutableStateOf<QItem?>(null) }

    DisposableEffect(Unit) {
        Scanner.onAlert = { popup = it; refresh++ }
        onDispose { Scanner.onAlert = null }
    }
    LaunchedEffect(openId) { openId?.let { id -> detail = Repo.quarantine(c).find { it.id == id }; onConsumed() } }

    var onboarded by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf<String?>(null) } // "history" | "quiz" | "ocr" | "qr"
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    LaunchedEffect(sharedImage) { sharedImage?.let { imageUri = it; overlay = "ocr"; onConsumed() } }

    if (!consent && !onboarded) { OnboardingScreen { onboarded = true }; return }
    if (!consent) {
        ConsentScreen { sms, notif, share ->
            Repo.setScope(c, "sms", sms); Repo.setScope(c, "notifications", notif); Repo.setScope(c, "share", share)
            Repo.recordConsent(c, listOfNotNull("sms".takeIf { sms }, "notifications".takeIf { notif }, "share".takeIf { share }), true)
            consent = true
        }
        return
    }
    // First run after consent: guided permission + battery checklist
    var setupDone by remember { mutableStateOf(Repo.setupDone(c)) }
    if (!setupDone) { SetupScreen(firstRun = true) { Repo.setSetupDone(c); setupDone = true }; return }

    // Phone's Back button: close the open screen / go to Scan tab instead of exiting the app
    androidx.activity.compose.BackHandler(enabled = detail != null || overlay != null || tab != Tab.Scan) {
        when {
            detail != null -> { detail = null; refresh++ }
            overlay != null -> { overlay = null; imageUri = null; refresh++ }
            else -> tab = Tab.Scan
        }
    }

    detail?.let { d -> DetailScreen(d, onBack = { detail = null; refresh++ }); return }
    when (overlay) {
        "history" -> { HistoryScreen { overlay = null }; return }
        "quiz" -> { QuizScreen { overlay = null }; return }
        "setup" -> { SetupScreen(firstRun = false) { overlay = null; refresh++ }; return }
        "ocr", "qr" -> {
            ImageScanScreen(overlay!!, imageUri, onBack = { overlay = null; imageUri = null; refresh++ },
                open = { detail = it; overlay = null; imageUri = null })
            return
        }
    }

    Box(Modifier.fillMaxSize().statusBarsPadding()) {
        key(refresh) {
            // smooth tab change: new screen slides in from the side it sits on in the bar, with a fade
            androidx.compose.animation.AnimatedContent(
                targetState = tab, label = "tabs",
                transitionSpec = {
                    val dir = if (targetState.ordinal > initialState.ordinal) 1 else -1
                    val spec = androidx.compose.animation.core.tween<androidx.compose.ui.unit.IntOffset>(260)
                    (androidx.compose.animation.slideInHorizontally(spec) { it / 6 * dir } +
                        androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260))) togetherWith
                        (androidx.compose.animation.slideOutHorizontally(spec) { -it / 6 * dir } +
                            androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(180)))
                },
            ) { t ->
                when (t) {
                    Tab.Scan -> HomeScreen(shared, onConsumed, openAlerts = { tab = Tab.Alerts }, open = { detail = it }, openHistory = { overlay = "history" }, openImage = { overlay = it })
                    // (Home's status chips also call openImage("setup") to reach the checklist)
                    Tab.Alerts -> AlertsScreen { detail = it }
                    Tab.Learn -> LearnScreen { overlay = "quiz" }
                    Tab.Settings -> SettingsScreen(onWithdraw = { consent = false }, onSetup = { overlay = "setup" })
                }
            }
        }
        FloatingNav(tab, Modifier.align(Alignment.BottomCenter)) { tab = it }
    }

    popup?.let { q ->
        AlertDialog(
            onDismissRequest = { popup = null }, containerColor = CardC,
            icon = { IconBubble(Icons.Filled.GppBad, verdictColor(q.verdict), verdictSoft(q.verdict), 56.dp) },
            title = { Text("${riskLabel(q.verdict)} message!", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("From ${q.sender} · Risk ${q.score}/100", color = Muted)
                    q.reasons.take(3).forEach { Text("• $it", color = Ink) }
                    Text("Moved to Alerts. Don't click links or share OTP.", color = Muted, fontSize = 13.sp)
                }
            },
            confirmButton = { TextButton({ detail = q; popup = null }) { Text("View details") } },
            dismissButton = { TextButton({ popup = null }) { Text("OK", color = Muted) } },
        )
    }
}

// ---------------- Floating pill nav (selected item expands) ----------------
@Composable
fun FloatingNav(current: Tab, modifier: Modifier, onSelect: (Tab) -> Unit) {
    // backdrop: page content fades out behind the bar instead of peeking around it
    Box(modifier.fillMaxWidth().background(Brush.verticalGradient(0f to Bg.copy(alpha = 0f), 0.35f to Bg, 1f to Bg))
        .padding(top = 24.dp)) {
    Row(
        Modifier.navigationBarsPadding().padding(16.dp).fillMaxWidth()
            .shadow(18.dp, RoundedCornerShape(36.dp), spotColor = Color(0x337C3AED))
            .background(CardC, RoundedCornerShape(36.dp)).padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
    ) {
        Tab.entries.forEach { t ->
            val sel = t == current
            val bg by androidx.compose.animation.animateColorAsState(if (sel) BlueSoft else Color.Transparent, label = "navBg")
            val tint by androidx.compose.animation.animateColorAsState(if (sel) Blue else Color(0xFF6B7280), label = "navTint")
            Row(
                Modifier.clip(RoundedCornerShape(28.dp)).background(bg)
                    // no grey ripple: the pill itself animates to show the tap
                    .clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        indication = null) { onSelect(t) }
                    .animateContentSize(androidx.compose.animation.core.spring(dampingRatio = 0.8f, stiffness = 500f))
                    .padding(horizontal = if (sel) 18.dp else 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(t.icon, t.label, tint = tint, modifier = Modifier.size(24.dp))
                if (sel) { Spacer(Modifier.width(6.dp)); Text(t.label, color = Blue, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
    }
}

// ---------------- Consent ----------------
@Composable
fun ConsentScreen(onAccept: (Boolean, Boolean, Boolean) -> Unit) {
    var sms by remember { mutableStateOf(true) }
    var notif by remember { mutableStateOf(true) }
    var share by remember { mutableStateOf(true) }
    var agree by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Spacer(Modifier.height(32.dp))
        Box(Modifier.align(Alignment.CenterHorizontally)) { BrandMark(84.dp) }
        Spacer(Modifier.height(16.dp))
        Text("Welcome to Phishing Net", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("One forward. Zero fraud.", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(28.dp))
        Text("Choose what we can check", fontWeight = FontWeight.SemiBold, color = Ink)
        Spacer(Modifier.height(8.dp))
        WhiteCard {
            ScopeRow(Icons.Outlined.Sms, "Incoming SMS", "Check new SMS for scam links", sms) { sms = it }
            HorizontalDivider(color = Line)
            ScopeRow(Icons.Outlined.Notifications, "App notifications", "WhatsApp, Telegram, Gmail", notif) { notif = it }
            HorizontalDivider(color = Line)
            ScopeRow(Icons.Outlined.Share, "Share to Phishing Net", "Check any link you share", share) { share = it }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().background(BlueSoft, RoundedCornerShape(14.dp)).padding(14.dp)) {
            Icon(Icons.Outlined.Lock, null, tint = Blue)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Your privacy (DPDP Act 2023)", fontWeight = FontWeight.SemiBold, color = Ink)
                listOf("Read-only — we never delete or send messages", "Only risky messages are checked",
                    "Message text is never stored on our server", "Withdraw & delete anytime in Settings")
                    .forEach { Text("• $it", color = Color(0xFF4B5563), fontSize = 13.sp) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp).clickable { agree = !agree }) {
            Checkbox(agree, { agree = it }, colors = CheckboxDefaults.colors(checkedColor = Blue))
            Text("I agree to the above", color = Ink)
        }
        BlueButton("Allow & Continue", enabled = agree) { onAccept(sms, notif, share) }
    }
}

@Composable
fun ScopeRow(icon: ImageVector, title: String, sub: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBubble(icon, Blue, BlueSoft, 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, color = Ink, fontWeight = FontWeight.Medium); Text(sub, color = Muted, fontSize = 13.sp) }
        Switch(on, set, colors = SwitchDefaults.colors(checkedTrackColor = Blue))
    }
}

// ---------------- Home: Security Scan ----------------
@Composable
fun HomeScreen(shared: String?, onConsumed: () -> Unit, openAlerts: () -> Unit, open: (QItem) -> Unit, openHistory: () -> Unit, openImage: (String) -> Unit) {
    val c = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val activity = c as MainActivity
    var text by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<JSONObject?>(null) }
    var lastTs by remember { mutableLongStateOf(0L) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var online by remember { mutableStateOf<Boolean?>(null) }

    fun run(t: String, source: String) {
        if (t.isBlank()) { error = "Paste a message or link first"; return }
        loading = true; error = null
        Repo.bg {
            val r = runCatching { Repo.check(c, t, source) }
            activity.runOnUiThread {
                loading = false
                r.onSuccess { j ->
                    result = j; lastTs = System.currentTimeMillis(); Repo.incStat(c, "scanned")
                    Repo.addHistory(c, t, j.getString("verdict"), j.getInt("risk_score"), source)
                    if (j.getString("verdict") != "Safe") {
                        val q = QItem(UUID.randomUUID().toString(), t, "Manual check", source, j.getString("verdict"),
                            j.getInt("risk_score"), j.getJSONArray("reasons_localized").toList(), j.getJSONArray("urls_found").toList(), System.currentTimeMillis())
                        Repo.addQ(c, q); Repo.incStat(c, "blocked"); Repo.bg { Repo.syncQ(c, q) }
                    }
                }.onFailure { error = "Can't reach server. Check Settings → Server URL" }
            }
        }
    }
    LaunchedEffect(shared) { shared?.let { text = it; run(it, "share"); onConsumed() } }
    LaunchedEffect(Unit) { Repo.bg { val ok = Repo.ping(c); activity.runOnUiThread { online = ok } } }

    val score = result?.getInt("risk_score") ?: 0
    val verdict = result?.getString("verdict") ?: "Safe"
    val threats = Repo.quarantine(c).filter { it.status == "quarantined" }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        // brand lockup + bell, then a short tagline instead of a generic "Security Scan" title
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            LogoLockup(Modifier.weight(1f), 40.dp)
            Box {
                RoundIconButton(Icons.Outlined.Notifications, openAlerts)
                if (Repo.unreadCount(c) > 0) Box(Modifier.size(10.dp).align(Alignment.TopEnd).background(HighC, CircleShape))
            }
        }
        Text("Check before you click", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(top = 14.dp))
        Text("Paste, scan or share any message — we'll tell you if it's a scam.", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 10.dp))
        StatusChips(online) { openImage("setup") }

        // Dial
        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Gauge(score, result?.let { verdict }, if (result == null) Blue else verdictColor(verdict), loading) {
                if (text.isBlank()) clipboard.getText()?.text?.let { text = it }
                run(text, "manual")
            }
        }

        WhiteCard {
            OutlinedTextField(
                text, { text = it }, Modifier.fillMaxWidth(), minLines = 2, maxLines = 4,
                placeholder = { Text("Paste a suspicious SMS, WhatsApp message or link", color = Muted) },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Line, focusedBorderColor = Blue, focusedTextColor = Ink, unfocusedTextColor = Ink),
                trailingIcon = { if (text.isNotEmpty()) IconButton({ text = ""; result = null }) { Icon(Icons.Default.Close, null, tint = Muted) } },
            )
            BlueButton(if (loading) "Scanning…" else "Scan message", enabled = !loading) { run(text, "manual") }
        }
        error?.let { Text(it, color = HighC, modifier = Modifier.padding(top = 8.dp)) }

        Spacer(Modifier.height(16.dp))
        QuickActions(
            onPaste = {
                val clip = clipboard.getText()?.text
                if (clip.isNullOrBlank()) error = "Clipboard is empty — copy a message first" else { text = clip; run(clip, "manual") }
            },
            onHistory = openHistory,
            onImage = { openImage("ocr") },
            onQr = { openImage("qr") },
        )
        Spacer(Modifier.height(16.dp))
        // Last scan card
        WhiteCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (result == null) "Your protection" else "Last scan", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.weight(1f))
                if (lastTs > 0) Text(ago(lastTs), fontSize = 12.sp, color = Muted,
                    modifier = Modifier.border1().padding(horizontal = 10.dp, vertical = 3.dp))
            }
            Row(Modifier.padding(vertical = 8.dp)) {
                StatCol(Repo.history(c).size.toString(), "Messages checked", Modifier.weight(1f))
                StatCol(threats.size.toString(), "Open alerts", Modifier.weight(1f))
            }
            val (bannerText, bannerColor, bannerBg) = when {
                result == null && threats.isEmpty() -> Triple("All clear! No threats detected", Ink, BlueSoft)
                result == null -> Triple(if (threats.size == 1) "1 open alert — tap the bell to review" else "${threats.size} open alerts — tap the bell to review", HighC, HighSoft)
                else -> {
                    val loc = result!!.optString("verdict_localized", verdict)
                    val label = if (verdict == "Safe") "Looks safe · no phishing signals" else "${riskLabel(verdict)} · ${score}/100"
                    Triple(if (loc != verdict) "$label · $loc" else label, verdictColor(verdict), verdictSoft(verdict))
                }
            }
            Row(Modifier.fillMaxWidth().background(bannerBg, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Info, null, tint = bannerColor, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp)); Text(bannerText, color = bannerColor, fontSize = 14.sp)
            }
            result?.let { r ->
                Spacer(Modifier.height(4.dp))
                val reasons = r.getJSONArray("reasons_localized").toList()
                reasons.forEach { Text("• $it", color = Color(0xFF374151), fontSize = 14.sp) }
                SpeakButton(verdict, score, reasons)
            }
        }

        Spacer(Modifier.height(16.dp))
        key(lastTs) { WeeklyActivity() } // re-read history after every scan
        TrendingScams { ex -> text = ex; run(ex, "manual") }

        Text("Recent Threats", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.padding(top = 20.dp, bottom = 10.dp))
        if (threats.isEmpty()) AlertRowEmpty()
        threats.take(3).forEach { AlertRow(it) { open(it) }; Spacer(Modifier.height(10.dp)) }
        Spacer(Modifier.height(110.dp)) // room for floating nav
    }
}

fun Modifier.border1() = this.border(1.dp, Line, RoundedCornerShape(50))

@Composable
fun Gauge(score: Int, verdict: String?, color: Color, loading: Boolean, onTap: () -> Unit) {
    // Safe results still show a small green arc so the dial visibly reacts
    val target = if (verdict == null) 0f else maxOf(score, 6) / 100f
    val anim by animateFloatAsState(target, tween(900), label = "gauge")
    Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val start = 135f; val sweep = 270f
            val r = size.minDimension / 2
            // tick marks around the dial
            val n = 60
            for (i in 0..n) {
                val f = i / n.toFloat()
                val a = Math.toRadians((start + sweep * f).toDouble())
                val major = i % 10 == 0
                val r1 = r - 6.dp.toPx(); val r2 = r1 - (if (major) 14.dp else 8.dp).toPx()
                drawLine(
                    if (f <= anim && anim > 0f) color.copy(alpha = .55f) else Color(0xFFCBD2DE),
                    Offset(center.x + r1 * cos(a).toFloat(), center.y + r1 * sin(a).toFloat()),
                    Offset(center.x + r2 * cos(a).toFloat(), center.y + r2 * sin(a).toFloat()),
                    strokeWidth = (if (major) 2.dp else 1.dp).toPx(), cap = StrokeCap.Round,
                )
            }
            val inset = 38.dp.toPx()
            val arc = Size(size.width - 2 * inset, size.height - 2 * inset)
            drawArc(Color(0xFFE3E8F0), start, sweep, false, Offset(inset, inset), arc, style = Stroke(16.dp.toPx(), cap = StrokeCap.Round))
            if (anim > 0f) drawArc(Brush.sweepGradient(listOf(color.copy(alpha = .5f), color, color.copy(alpha = .5f))), start, sweep * anim, false,
                Offset(inset, inset), arc, style = Stroke(16.dp.toPx(), cap = StrokeCap.Round))
            val a = Math.toRadians((start + sweep * anim).toDouble()); val rr = arc.width / 2
            val dot = Offset(center.x + rr * cos(a).toFloat(), center.y + rr * sin(a).toFloat())
            drawCircle(Color.White, 10.dp.toPx(), dot); drawCircle(color, 6.dp.toPx(), dot)
        }
        Box(
            Modifier.size(140.dp).shadow(20.dp, CircleShape, spotColor = Color(0x557C3AED)).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color.White, Color(0xFFF1F4FA)))).clickable { onTap() },
            contentAlignment = Alignment.Center,
        ) {
            when {
                loading -> CircularProgressIndicator(color = Blue, strokeWidth = 3.dp)
                verdict == null -> Icon(Icons.Outlined.DocumentScanner, null, tint = Blue, modifier = Modifier.size(56.dp))
                verdict == "Safe" -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.VerifiedUser, null, tint = SafeC, modifier = Modifier.size(52.dp))
                    Text("Safe", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = SafeC)
                    Text("risk $score / 100", fontSize = 12.sp, color = Muted)
                }
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$score", fontSize = 42.sp, fontWeight = FontWeight.Bold, color = color)
                    Text(riskLabel(verdict), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = color)
                    Text("risk / 100", fontSize = 12.sp, color = Muted)
                }
            }
        }
        Text(if (loading) "Scanning…" else if (verdict == null) "Tap to Scan" else "Tap to scan again", color = Color(0xFF4B5563),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp))
    }
}

@Composable
fun StatusChips(online: Boolean?, openSetup: () -> Unit) {
    val c = LocalContext.current
    val tick = rememberResumeTick()
    val sms = remember(tick) { Repo.scope(c, "sms") && Perms.sms(c) }
    val notif = remember(tick) { Repo.scope(c, "notifications") && notifAccessGranted(c) }
    val battery = remember(tick) { Perms.battery(c) }
    Column {
        Row(Modifier.fillMaxWidth().padding(top = 4.dp).clickable { openSetup() }, horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
            MiniChip("SMS", sms); MiniChip("Apps", notif); MiniChip("Battery", battery); MiniChip(if (online == true) "Online" else "Offline", online == true)
        }
        if (!(sms && notif && battery)) Row(
            Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFF4E0)).clickable { openSetup() }.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Warning, null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
            Text("Protection is limited — tap to finish setup", color = Color(0xFF92400E), fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("Fix →", color = Color(0xFFD97706), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun MiniChip(label: String, on: Boolean) {
    Row(Modifier.background(if (on) SafeSoft else HighSoft, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(if (on) SafeC else HighC, CircleShape))
        Spacer(Modifier.width(6.dp)); Text(label, fontSize = 12.sp, color = if (on) SafeC else HighC, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun StatCol(v: String, label: String, m: Modifier) {
    Column(m) { Text(v, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Ink); Text(label, color = Muted, fontSize = 14.sp) }
}

// ---------------- Alerts (quarantine) ----------------
@Composable
fun AlertsScreen(open: (QItem) -> Unit) {
    val c = LocalContext.current
    var filter by remember { mutableStateOf("all") }
    var ver by remember { mutableIntStateOf(0) } // bump to re-read after mark-read / remove
    val all = remember(ver) { Repo.quarantine(c) }
    val unread = remember(ver) { Repo.unreadCount(c) }
    var confirmClear by remember { mutableStateOf(false) }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, containerColor = CardC,
        icon = { IconBubble(Icons.Outlined.DeleteSweep, HighC, HighSoft, 56.dp) },
        title = { Text("Clear all alerts?", fontWeight = FontWeight.Bold) },
        text = { Text("This removes all ${all.size} alerts from Phishing Net. Your original messages in SMS / WhatsApp are not touched. This can't be undone.", color = Muted) },
        confirmButton = { TextButton({ Repo.clearAllQ(c); ver++; confirmClear = false }) { Text("Clear all", color = HighC, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel", color = Muted) } },
    )
    val items = all.filter {
        when (filter) {
            "high" -> it.verdict == "Phishing" && it.status == "quarantined"
            "medium" -> it.verdict == "Suspicious" && it.status == "quarantined"
            "reported" -> it.status == "reported"
            "safe" -> it.status == "marked_safe"
            else -> true
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenHeader("Alerts", badge = false, onBell = null)
        Text("Risky messages are copied here. Your originals are untouched.", color = Muted, fontSize = 13.sp)
        if (all.isNotEmpty()) Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (unread == 0) "All caught up" else "$unread unread", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            if (unread > 0) Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { Repo.markAllRead(c); ver++ }.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.DoneAll, null, tint = Blue, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                Text("Mark all read", color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
            Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { confirmClear = true }.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.DeleteSweep, null, tint = HighC, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                Text("Clear all", color = HighC, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("all" to "All", "high" to "High Risk", "medium" to "Medium Risk", "reported" to "Reported", "safe" to "Marked Safe").forEach { (k, l) ->
                val sel = filter == k
                Text(l, color = if (sel) Color.White else Color(0xFF4B5563), fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(if (sel) Blue else CardC)
                        .clickable { filter = k }.padding(horizontal = 18.dp, vertical = 12.dp))
            }
        }
        if (items.isEmpty()) AlertRowEmpty()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
            items(items, key = { it.id }) { q ->
                AlertRow(q, unread = q.status == "quarantined" && !Repo.isRead(c, q.id),
                    onRemove = { Repo.removeQ(c, q.id); ver++ }) { Repo.markRead(c, q.id); open(q) }
            }
        }
    }
}

fun sourceIcon(source: String): Triple<ImageVector, Color, Color> = when (source) {
    "whatsapp", "whatsapp business" -> Triple(Icons.Outlined.Chat, Color(0xFF25D366), Color(0xFFE7F9EE))
    "telegram" -> Triple(Icons.AutoMirrored.Filled.Send, Color(0xFF229ED9), Color(0xFFE6F4FB))
    "gmail" -> Triple(Icons.Outlined.Email, Color(0xFFEA4335), Color(0xFFFDECEA))
    "instagram" -> Triple(Icons.Outlined.PhotoCamera, Color(0xFFC13584), Color(0xFFFBE9F3))
    "messenger" -> Triple(Icons.Outlined.Forum, Color(0xFF8B5CF6), Color(0xFFF1EBFE))
    "sms", "messages", "truecaller" -> Triple(Icons.Outlined.Sms, Blue, BlueSoft)
    "share" -> Triple(Icons.Outlined.Link, Color(0xFFF59E0B), Color(0xFFFFF4E0))
    "image" -> Triple(Icons.Outlined.Image, Color(0xFF0EA5E9), Color(0xFFE0F2FE))
    "qr" -> Triple(Icons.Outlined.QrCode2, Color(0xFF7C3AED), Color(0xFFF1EBFE))
    else -> Triple(Icons.Outlined.Search, Blue, BlueSoft)
}

@Composable
fun AlertRow(q: QItem, unread: Boolean = false, onRemove: (() -> Unit)? = null, onClick: () -> Unit) {
    val (icon, tint, bg) = sourceIcon(q.source)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardC).clickable { onClick() }
            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = if (onRemove != null) 6.dp else 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            IconBubble(icon, tint, bg, 48.dp)
            if (unread) Box(Modifier.align(Alignment.TopEnd).size(12.dp).background(Color.White, CircleShape).padding(2.dp).background(Blue, CircleShape))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            // the message itself is the title, so alerts are easy to tell apart
            Text(q.text.replace("\n", " "), color = Ink, fontSize = 16.sp, raw = true,
                fontWeight = if (unread) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${q.sender.ifBlank { q.source }} • ${ago(q.ts)}", color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        when (q.status) {
            "reported" -> Pill("Reported", SafeC, SafeSoft)
            "marked_safe" -> Pill("Safe", SafeC, SafeSoft)
            else -> Pill(riskLabel(q.verdict), verdictColor(q.verdict), verdictSoft(q.verdict))
        }
        if (onRemove != null) Box(Modifier.size(36.dp).clip(CircleShape).clickable { onRemove() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Close, "Remove", tint = Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun AlertRowEmpty() {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardC).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBubble(Icons.Outlined.CheckCircle, SafeC, SafeSoft, 48.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Text("No threats", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Medium); Text("You're all clear", color = Muted) }
        Pill("Clean", SafeC, SafeSoft)
    }
}

fun ago(ts: Long): String {
    val m = (System.currentTimeMillis() - ts) / 60000
    return when { m < 1 -> "just now"; m < 60 -> "$m min ago"; m < 1440 -> "${m / 60} hours ago"; else -> "${m / 1440} days ago" }
}

// ---------------- Detail ----------------
@Composable
fun DetailScreen(q: QItem, onBack: () -> Unit) {
    val c = LocalContext.current
    val (icon, tint, bg) = sourceIcon(q.source)
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(Icons.AutoMirrored.Filled.ArrowBack, onBack)
            Spacer(Modifier.width(12.dp))
            Text("Threat details", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        }
        WhiteCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(icon, tint, bg, 52.dp); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(q.sender.ifBlank { q.source }, color = Ink, fontWeight = FontWeight.SemiBold, raw = true)
                    Text("${q.source} • ${ago(q.ts)}", color = Muted, fontSize = 13.sp)
                }
                Pill(riskLabel(q.verdict), verdictColor(q.verdict), verdictSoft(q.verdict))
            }
            Text("Risk score", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${q.score}", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = verdictColor(q.verdict))
                Text(" / 100", color = Muted)
            }
            Box(Modifier.fillMaxWidth().height(10.dp).background(Line, RoundedCornerShape(5.dp))) {
                Box(Modifier.fillMaxWidth(q.score / 100f).fillMaxHeight().background(verdictColor(q.verdict), RoundedCornerShape(5.dp)))
            }
        }
        WhiteCard {
            Text("Message", fontWeight = FontWeight.SemiBold, color = Ink)
            Text(q.text, raw = true, color = Color(0xFF374151), modifier = Modifier.fillMaxWidth().background(Bg, RoundedCornerShape(12.dp)).padding(12.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SpeakButton(q.verdict, q.score, q.reasons)
            Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xFFE7F9EE)).clickable { warnFamily(c, q) }
                .padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.FamilyRestroom, null, tint = Color(0xFF16A34A), modifier = Modifier.size(18.dp))
                Text(" Warn family", color = Color(0xFF16A34A), fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }
        WhiteCard {
            Text("Why we flagged it", fontWeight = FontWeight.SemiBold, color = Ink)
            q.reasons.forEach { r ->
                Row(Modifier.padding(vertical = 2.dp)) {
                    Icon(Icons.Outlined.Warning, null, tint = verdictColor(q.verdict), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp)); Text(r, color = Color(0xFF374151), fontSize = 14.sp)
                }
            }
        }
        if (q.urls.isNotEmpty()) WhiteCard {
            Text("Links — do NOT open", fontWeight = FontWeight.SemiBold, color = Ink)
            q.urls.forEach { Text(it.replace(".", "[.]"), color = HighC, fontSize = 14.sp, raw = true) }
        }
        BlueButton("Report scam · cybercrime.gov.in") {
            Repo.report(c, q); Repo.setStatus(c, q.id, "reported")
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://cybercrime.gov.in")))
        }
        OutlineBtn("Call 1930 helpline", Icons.Outlined.Call, Ink) { c.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:1930"))) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.weight(1f)) { OutlineBtn("Mark safe", Icons.Outlined.CheckCircle, SafeC) { Repo.setStatus(c, q.id, "marked_safe"); onBack() } }
            Box(Modifier.weight(1f)) { OutlineBtn("Remove", Icons.Outlined.Delete, HighC) { Repo.removeQ(c, q.id); onBack() } }
        }
    }
}

// ---------------- Learn ----------------
@Composable
fun LearnScreen(openQuiz: () -> Unit) {
    val tips = listOf(
        Triple(Icons.Outlined.AccountBalance, "Banks never ask for KYC via SMS links", "SBI, HDFC and others never send a link to update KYC or PAN."),
        Triple(Icons.Outlined.Password, "Never share OTP, PIN or CVV", "No genuine caller or message will ask for your OTP."),
        Triple(Icons.Outlined.Bolt, "Electricity bill threats are fake", "Boards don't disconnect 'tonight' via SMS with a personal number."),
        Triple(Icons.Outlined.LocalShipping, "Parcel held? Pay ₹50? Scam.", "India Post and couriers don't ask for small fees on WhatsApp."),
        Triple(Icons.Outlined.Redeem, "You didn't win a lottery", "Prizes you never entered are always scams."),
        Triple(Icons.Outlined.Link, "Check the link spelling", "amaz0n, sbi-kyc, hdfc-bank.xyz — look-alike sites steal passwords."),
        Triple(Icons.Outlined.Call, "Lost money? Golden hour", "Call 1930 immediately or report at cybercrime.gov.in."),
    )
    LazyColumn(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
        item { ScreenHeader("Stay Safe", badge = false, onBell = null); Text("Spot a scam in 10 seconds", color = Muted) }
        item { QuizPromo(openQuiz) }
        items(tips) { (ic, t, d) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardC).padding(16.dp)) {
                IconBubble(ic, Blue, BlueSoft, 44.dp); Spacer(Modifier.width(14.dp))
                Column { Text(t, fontWeight = FontWeight.SemiBold, color = Ink); Text(d, color = Muted, fontSize = 14.sp) }
            }
        }
        item {
            val ctx = LocalContext.current
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF2AABEE), Color(0xFF229ED9))))
                .clickable { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/phishingnet0bot"))) }
                .padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.ic_telegram), null, Modifier.size(30.dp)); Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Telegram checker", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text("@phishingnet0bot", color = Color.White, fontSize = 14.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Forward any message to our Telegram bot and get a verdict in your language. Tap to open.", color = Color(0xFFE3F4FD))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(BlueGrad).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.ic_whatsapp), null, Modifier.size(30.dp)); Spacer(Modifier.width(10.dp))
                    Text("WhatsApp checker · Coming soon", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                }
                Spacer(Modifier.height(6.dp))
                Text("Forward any message to our WhatsApp number and get a verdict in your language.", color = Color(0xFFDCE7FF))
            }
        }
    }
}

// ---------------- Settings ----------------
@Composable
fun SettingsScreen(onWithdraw: () -> Unit, onSetup: () -> Unit) {
    val c = LocalContext.current
    var url by remember { mutableStateOf(Repo.serverUrl(c)) }
    var saved by remember { mutableStateOf(false) }
    var devTaps by remember { mutableIntStateOf(0) }
    var lang by remember { mutableStateOf(Repo.language(c)) }
    var sms by remember { mutableStateOf(Repo.scope(c, "sms")) }
    var notif by remember { mutableStateOf(Repo.scope(c, "notifications")) }
    var confirm by remember { mutableStateOf(false) }
    val langs = listOf("auto" to "Auto", "en-IN" to "English", "hi-IN" to "हिंदी", "kn-IN" to "ಕನ್ನಡ", "ta-IN" to "தமிழ்",
        "te-IN" to "తెలుగు", "ml-IN" to "മലയാളം", "mr-IN" to "मराठी", "bn-IN" to "বাংলা")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenHeader("Settings", badge = false, onBell = null)
        SectionLabel("Protection")
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(if (Perms.allGood(c)) SafeSoft else Color(0xFFFFF4E0))
            .clickable { onSetup() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (Perms.allGood(c)) Icons.Outlined.VerifiedUser else Icons.Outlined.Checklist, null, tint = if (Perms.allGood(c)) SafeC else Color(0xFFD97706))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (Perms.allGood(c)) "Protection setup complete" else "Finish setup", fontWeight = FontWeight.SemiBold, color = Ink)
                Text(if (Perms.allGood(c)) "All 5 steps done ✓ · tap to review" else "Some steps missing — protection is limited", color = Muted, fontSize = 13.sp)
            }
            Text("→", color = Muted, fontSize = 18.sp)
        }
        WhiteCard {
            ScopeRow(Icons.Outlined.Sms, "Scan SMS", "Incoming text messages", sms) { sms = it; Repo.setScope(c, "sms", it); if (it) (c as MainActivity).askPerms(true) }
            HorizontalDivider(color = Line)
            ScopeRow(Icons.Outlined.Notifications, "Scan app notifications", if (notifAccessGranted(c)) "Access granted" else "Tap to grant access", notif) {
                notif = it; Repo.setScope(c, "notifications", it)
                if (it && !notifAccessGranted(c)) c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        SectionLabel("App language")
        WhiteCard {
            Text("The whole app, alerts and spoken warnings switch to this language. First switch needs internet once.", color = Muted, fontSize = 13.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                langs.forEach { (k, l) ->
                    val sel = lang == k
                    // fixed-height box keeps Indian scripts vertically centred
                    Box(Modifier.height(40.dp).clip(RoundedCornerShape(12.dp)).background(if (sel) Blue else Bg)
                        .clickable { lang = k; I18n.setLanguage(c, k) }.padding(horizontal = 14.dp), contentAlignment = Alignment.Center) {
                        Text(l, color = if (sel) Color.White else Ink, fontSize = 15.sp, raw = true) // language names stay native
                    }
                }
            }
        }
        SectionLabel("Family protection")
        WhiteCard {
            var fam by remember { mutableStateOf(Repo.family(c)) }
            Text("Trusted contact's number — they get an automatic SMS when a scam is caught (if turned on below), or tap “Warn family” on any alert to send them a WhatsApp heads-up.", color = Muted, fontSize = 13.sp)
            OutlinedTextField(fam, { fam = it; Repo.setFamily(c, it) }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp),
                placeholder = { Text("e.g. 9876543210", color = Muted) },
                leadingIcon = { Icon(Icons.Outlined.FamilyRestroom, null, tint = Muted) },
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Line, focusedBorderColor = Blue, focusedTextColor = Ink, unfocusedTextColor = Ink))
            // automatic alert: needs SEND_SMS; re-checked every time the screen resumes
            val tick = rememberResumeTick()
            val canSend = remember(tick) { FamilyAlert.canSend(c) }
            var auto by remember { mutableStateOf(Repo.autoFamily(c)) }
            ScopeRow(Icons.Outlined.NotificationImportant, "Auto-alert family",
                if (auto && !canSend) "Tap to allow sending SMS" else "Sends them an SMS automatically when a High Risk scam reaches you (max 5 a day)", auto && canSend) { on ->
                auto = on; Repo.setAutoFamily(c, on)
                if (on && !FamilyAlert.canSend(c)) (c as MainActivity).askSendSms()
            }
            if (auto && fam.filter { it.isDigit() }.length < 10) Text("Add a 10-digit number above to turn this on.", color = HighC, fontSize = 12.sp)
        }
        // Hidden developer section: tap the version line 7 times to show it (users never see it)
        if (devTaps >= 7) SectionLabel("Developer · Server")
        if (devTaps >= 7) WhiteCard {
            OutlinedTextField(url, { url = it; saved = false }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp),
                leadingIcon = { Icon(Icons.Outlined.Dns, null, tint = Muted) },
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Line, focusedBorderColor = Blue, focusedTextColor = Ink, unfocusedTextColor = Ink))
            BlueButton(if (saved) "Saved ✓" else "Save") { Repo.setServerUrl(c, url); saved = true }
            Text("Default: https://phishing-net.onrender.com", color = Muted, fontSize = 12.sp)
        }
        SectionLabel("Privacy (DPDP Act 2023)")
        WhiteCard {
            Text("Device ID: ${Repo.userId(c).take(8)}…", color = Muted, fontSize = 13.sp)
            OutlineBtn("Withdraw consent & delete my data", Icons.Outlined.DeleteForever, HighC) { confirm = true }
        }
        Text("Phishing Net v1.0 · One forward. Zero fraud.", color = Muted, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null) { devTaps++ })
        Spacer(Modifier.height(110.dp))
    }
    if (confirm) AlertDialog({ confirm = false }, containerColor = CardC,
        title = { Text("Delete everything?", color = Ink) },
        text = { Text("This withdraws consent, stops scanning and deletes your alerts and server records.", color = Muted) },
        confirmButton = { TextButton({ Repo.deleteAll(c); confirm = false; onWithdraw() }) { Text("Delete", color = HighC) } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel", color = Muted) } })
}

// ---------------- shared widgets ----------------
@Composable
fun ScreenHeader(title: String, badge: Boolean, onBell: (() -> Unit)?) {
    // bell only shown where it does something (Home -> opens Alerts)
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
        if (onBell != null) Box {
            RoundIconButton(Icons.Outlined.Notifications, onBell)
            if (badge) Box(Modifier.size(10.dp).align(Alignment.TopEnd).background(HighC, CircleShape))
        }
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).shadow(6.dp, CircleShape, spotColor = Color(0x22000000)).clip(CircleShape).background(CardC).clickable { onClick() },
        contentAlignment = Alignment.Center) { Icon(icon, null, tint = Ink) }
}

@Composable
fun IconBubble(icon: ImageVector, tint: Color, bg: Color, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size).background(bg, CircleShape), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun Pill(text: String, fg: Color, bg: Color) {
    Text(text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.background(bg, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 5.dp))
}

@Composable
fun SectionLabel(t: String) = Text(t, color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 4.dp))

@Composable
fun WhiteCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CardC).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
fun BlueButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(54.dp)
        .shadow(if (enabled) 10.dp else 0.dp, RoundedCornerShape(16.dp), spotColor = Color(0x667C3AED))
        .clip(RoundedCornerShape(16.dp))
        .background(if (enabled) BlueGrad else Brush.verticalGradient(listOf(Color(0xFFC7D2E5), Color(0xFFC7D2E5))))
        .clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun OutlineBtn(text: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    OutlinedButton(onClick, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = CardC)) {
        Icon(icon, null, tint = color, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(text, color = color)
    }
}
