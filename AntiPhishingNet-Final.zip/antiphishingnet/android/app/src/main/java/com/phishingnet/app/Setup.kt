package com.phishingnet.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

// ======================= Permission / background status checks =======================
object Perms {
    fun sms(c: Context) = ContextCompat.checkSelfPermission(c, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
    fun notifPost(c: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    fun listener(c: Context) = notifAccessGranted(c)
    fun battery(c: Context) = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)

    fun overlay(c: Context) = Settings.canDrawOverlays(c)

    /** Everything needed for real-time protection. */
    fun allGood(c: Context) = sms(c) && notifPost(c) && listener(c) && battery(c) && overlay(c)

    fun askOverlay(c: Context) = c.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun openAppInfo(c: Context) = c.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    @SuppressLint("BatteryLife") // sideloaded safety app: asking directly is the clearest UX
    fun askBattery(c: Context) {
        runCatching {
            c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}")))
        }.onFailure { openAppInfo(c) }
    }
}

/** Re-runs [block] every time the screen comes back to the foreground (after returning from Settings). */
@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    @Suppress("DEPRECATION")
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

// ======================= Setup checklist screen =======================
@Composable
fun SetupScreen(firstRun: Boolean, onDone: () -> Unit) {
    val c = LocalContext.current
    val act = c as MainActivity
    val tick = rememberResumeTick()
    // read live status (recomputed on every resume)
    val sms = remember(tick) { Perms.sms(c) }
    val post = remember(tick) { Perms.notifPost(c) }
    val listener = remember(tick) { Perms.listener(c) }
    val battery = remember(tick) { Perms.battery(c) }
    val overlay = remember(tick) { Perms.overlay(c) }
    val needRestricted = Build.VERSION.SDK_INT >= 33 && (!sms || !listener)
    val total = 5
    val done = listOf(sms, post, listener, battery, overlay).count { it }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!firstRun) { RoundIconButton(Icons.AutoMirrored.Filled.ArrowBack, onDone); Spacer(Modifier.width(12.dp)) }
            Column {
                Text("Finish setup", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("So Phishing Net can protect you even when the app is closed", color = Muted, fontSize = 14.sp)
            }
        }
        // progress
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(if (done == total) SafeSoft else BlueSoft).padding(16.dp)) {
            Text(if (done == total) "🛡️ " + tr("Fully protected!") else "$done / $total " + tr("steps done"), fontWeight = FontWeight.SemiBold, color = if (done == total) SafeC else Blue, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp)); LinearBar(done / total.toFloat())
        }

        if (needRestricted) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFFFFF4E0)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.LockOpen, null, tint = Color(0xFFD97706)); Spacer(Modifier.width(8.dp))
                    Text("Step 0 · Allow restricted settings", fontWeight = FontWeight.SemiBold, color = Ink)
                }
                Text("Android blocks SMS & notification access for apps installed outside the Play Store. If a switch below is greyed out:", color = Color(0xFF4B5563), fontSize = 14.sp)
                Text("1. Tap the button below → App info\n2. Tap ⋮ (top-right) → Allow restricted settings\n3. Confirm with your PIN, then come back", color = Ink, fontSize = 14.sp)
                SmallBtn("Open App info", Color(0xFFD97706)) { Perms.openAppInfo(c) }
            }
        }

        SetupStep(1, Icons.Outlined.Sms, "Read incoming SMS", "Check every new SMS for scam links", sms) { act.askPerms(true) }
        SetupStep(2, Icons.Outlined.Forum, "Notification access", "Check WhatsApp, Telegram & Gmail messages", listener) {
            c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        SetupStep(3, Icons.Outlined.NotificationsActive, "Show scam alerts", "Pop-up warning when a scam arrives", post) { act.askPerms(false) }
        SetupStep(4, Icons.Outlined.BatteryChargingFull, "Battery: Unrestricted", "Stops your phone from putting Phishing Net to sleep", battery) { Perms.askBattery(c) }
        SetupStep(5, Icons.Outlined.Layers, "Display over other apps", "Big red warning on top of WhatsApp or Messages when a scam arrives", overlay) { Perms.askOverlay(c) }

        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardC).padding(16.dp)) {
            Icon(Icons.Outlined.TipsAndUpdates, null, tint = Blue); Spacer(Modifier.width(10.dp))
            Column {
                Text("Keep it running", fontWeight = FontWeight.SemiBold, color = Ink)
                Text("Closing the app is fine. Don't use “Force stop” in App info — that pauses protection until you open the app again.", color = Muted, fontSize = 14.sp)
            }
        }

        BlueButton(if (done == total) "Start protecting me" else if (firstRun) "Continue" else "Done") { onDone() }
        if (firstRun && done < total) Text("You can finish this later from Settings → Finish setup", color = Muted, fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun SetupStep(n: Int, icon: ImageVector, title: String, sub: String, ok: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardC).clickable(enabled = !ok) { onFix() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        IconBubble(icon, if (ok) SafeC else Blue, if (ok) SafeSoft else BlueSoft, 46.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("STEP $n", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (ok) SafeC else Blue, letterSpacing = 1.sp)
            Text(title, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 16.sp)
            Text(sub, color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.width(8.dp))
        if (ok) Box(Modifier.size(30.dp).background(SafeC, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
        } else SmallBtn("Allow", Blue, onFix)
    }
}

@Composable
fun SmallBtn(label: String, color: Color, onClick: () -> Unit) {
    Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(color).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp))
}
