package com.phishingnet.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.util.UUID

/**
 * Shared scan pipeline for SMS, notifications and share-intent.
 * 1. Local pre-filter: only messages with a link / phone number / risky keyword leave the phone.
 * 2. Server /check.
 * 3. Suspicious or Phishing -> soft quarantine (copy, original untouched) + alert notification.
 */
object Scanner {
    private const val CHANNEL = "alerts"
    private val RISKY = Regex(
        "https?://|www\\.|\\b[a-z0-9-]+\\.(com|in|xyz|top|shop|info|ly|online|site|link|click)\\b|" +
            "kyc|otp|urgent|block|suspend|refund|prize|lottery|won|reward|click|electricity|disconnect|" +
            "parcel|courier|pay|₹|rs\\.?\\s?\\d|\\d{10}|" +
            "[\\u0900-\\u0D7F]", // any Indic script text -> let the server translate & judge
        RegexOption.IGNORE_CASE,
    )
    private val recent = LinkedHashSet<Int>() // de-duplicate repeated notifications

    /** Listeners (UI) that want to know when a new alert arrives. */
    var onAlert: ((QItem) -> Unit)? = null

    /** True while MainActivity is in the foreground (set in onResume/onPause). */
    @Volatile var appVisible = false

    fun worthChecking(text: String) = text.length >= 8 && RISKY.containsMatchIn(text)

    fun scan(c: Context, text: String, source: String, sender: String) {
        if (!Repo.hasConsent(c) || !worthChecking(text)) return
        I18n.init(c) // so background alerts/notifications use the app language
        synchronized(recent) {
            if (!recent.add(text.hashCode())) return
            if (recent.size > 100) recent.remove(recent.first())
        }
        Repo.bg {
            val r = Repo.check(c, text, source)
            Repo.incStat(c, "scanned")
            val verdict = r.getString("verdict")
            Repo.addHistory(c, text, verdict, r.getInt("risk_score"), source)
            if (verdict == "Safe") return@bg
            val item = QItem(
                UUID.randomUUID().toString(), text, sender, source, verdict, r.getInt("risk_score"),
                r.getJSONArray("reasons_localized").toList(), r.getJSONArray("urls_found").toList(),
                System.currentTimeMillis(),
            )
            Repo.addQ(c, item)
            Repo.incStat(c, "blocked")
            runCatching { Repo.syncQ(c, item) }
            val famSent = FamilyAlert.maybeSend(c, item)
            notify(c, item, famSent)
            // App on screen -> in-app dialog. Otherwise -> full-screen warning over the current app.
            if (appVisible) Handler(Looper.getMainLooper()).post { onAlert?.invoke(item) }
            else AlertOverlay.show(c, item)
        }
    }

    private fun notify(c: Context, q: QItem, famSent: Boolean = false) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Scam alerts", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(
            c, q.id.hashCode(),
            Intent(c, MainActivity::class.java).putExtra("open_id", q.id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val icon = if (q.verdict == "Phishing") "🚨" else "⚠️"
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("$icon ${tr(riskLabel(q.verdict))} · ${q.sender.ifBlank { q.source }}")
            .setContentText("${tr("Risk")} ${q.score}/100 · ${q.reasons.firstOrNull() ?: ""}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("${tr("Risk")} ${q.score}/100\n" + q.reasons.take(3).joinToString("\n") { "• $it" } +
                "\n" + tr("Don't click links or share OTP. Moved to Quarantine.") +
                (if (famSent) "\n👨‍👩‍👧 " + tr("Your family contact was alerted by SMS.") else "")))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setColor(if (q.verdict == "Phishing") 0xFFEF4444.toInt() else 0xFFF59E0B.toInt())
            .setContentIntent(open).setAutoCancel(true).build()
        runCatching { nm.notify(q.id.hashCode(), n) }
    }
}
