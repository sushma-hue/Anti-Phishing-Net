package com.phishingnet.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

/**
 * Automatic family alert: when a High Risk (Phishing) message arrives, text the trusted contact.
 * Uses a plain SMS because WhatsApp can't be sent without the user tapping Send.
 * The scam link is NOT forwarded (links are replaced) so the family member can't click it by mistake.
 */
object FamilyAlert {
    private const val DAILY_MAX = 5

    fun canSend(c: Context) =
        ContextCompat.checkSelfPermission(c, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    /** Returns true if an SMS was sent. */
    fun maybeSend(c: Context, q: QItem): Boolean {
        if (q.verdict != "Phishing" || !Repo.autoFamily(c) || !canSend(c)) return false
        val digits = Repo.family(c).filter { it.isDigit() }
        if (digits.length < 10 || Repo.famSentToday(c) >= DAILY_MAX) return false
        val to = if (digits.length == 10) "+91$digits" else "+$digits"
        val snippet = q.text.replace(Regex("(https?://\\S+|www\\.\\S+|\\b[\\w-]+\\.(com|in|xyz|top|shop|info|ly|online|site|link|click)\\S*)", RegexOption.IGNORE_CASE), "[link removed]")
            .replace("\n", " ").take(90)
        val from = q.sender.ifBlank { q.source }
        val msg = "Phishing Net: a High Risk scam (risk ${q.score}/100) was sent to your family member from $from: \"$snippet\". " +
            "Please call them and remind them not to click links, pay, or share OTP. Help: 1930"
        return runCatching {
            val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
            sm.sendMultipartTextMessage(to, null, sm.divideMessage(msg), null, null)
            Repo.incFamSent(c)
            true
        }.getOrElse { it.printStackTrace(); false }
    }
}
