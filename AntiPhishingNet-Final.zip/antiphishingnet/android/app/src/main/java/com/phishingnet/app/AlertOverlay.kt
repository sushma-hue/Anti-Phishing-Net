package com.phishingnet.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Full-screen scam warning drawn OVER any app (WhatsApp, Messages, ...).
 * Needs "Display over other apps" (SYSTEM_ALERT_WINDOW), granted in the setup checklist.
 * Built with plain Android views so it works without the app's activity being open.
 */
object AlertOverlay {
    private var current: View? = null

    fun canShow(c: Context) = Settings.canDrawOverlays(c)

    fun show(c: Context, q: QItem) {
        if (!canShow(c)) return
        Handler(Looper.getMainLooper()).post { runCatching { attach(c.applicationContext, q) }.onFailure { it.printStackTrace() } }
    }

    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; if (stroke > 0) setStroke(stroke, strokeColor)
    }

    private fun attach(c: Context, q: QItem) {
        val wm = c.getSystemService(WindowManager::class.java)
        dismiss(wm)
        val high = q.verdict == "Phishing"
        val accent = if (high) Color.parseColor("#E5484D") else Color.parseColor("#F59E0B")
        val soft = if (high) Color.parseColor("#FDECEC") else Color.parseColor("#FFF4E0")
        val ink = Color.parseColor("#111827")
        val muted = Color.parseColor("#6B7280")
        val r = dp(c, 28).toFloat()

        fun text(s: String, size: Float, color: Int, bold: Boolean = false, center: Boolean = false, raw: Boolean = false) = TextView(c).apply {
            text = if (raw) s else tr(s); textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            if (center) gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(c, 4), 0, dp(c, 4))
        }

        fun button(label: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(c).apply {
            text = tr(label); textSize = 17f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = rounded(bg, dp(c, 16).toFloat(), if (bg == Color.WHITE) dp(c, 1) else 0, Color.parseColor("#E6EAF2"))
            setPadding(0, dp(c, 16), 0, dp(c, 16))
            setOnClickListener { onClick() }
        }

        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, r)
            setPadding(dp(c, 24), dp(c, 24), dp(c, 24), dp(c, 20))
        }
        // header: big warning badge
        card.addView(TextView(c).apply {
            text = "⚠"; textSize = 44f; setTextColor(accent); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(soft) }
        }, LinearLayout.LayoutParams(dp(c, 96), dp(c, 96)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(c, 12) })
        card.addView(text(if (high) "SCAM ALERT!" else "Suspicious message", 28f, accent, bold = true, center = true))
        card.addView(text("${riskLabel(q.verdict)} · Risk ${q.score}/100", 16f, ink, bold = true, center = true))
        card.addView(text("From ${q.sender.ifBlank { q.source }}", 14f, muted, center = true))

        // the message
        card.addView(text(q.text.take(220), 15f, ink, raw = true).apply {
            background = rounded(Color.parseColor("#F3F6FB"), dp(c, 14).toFloat())
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 12); bottomMargin = dp(c, 8) })

        q.reasons.take(3).forEach { card.addView(text("•  $it", 14f, ink, raw = true)) }

        card.addView(text("Do NOT click any link, call back, pay, or share your OTP / PIN.", 15f, accent, bold = true).apply {
            background = rounded(soft, dp(c, 14).toFloat()); setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 10); bottomMargin = dp(c, 14) })

        val root = ScrollView(c).apply { setBackgroundColor(Color.parseColor("#D9000000")); isFillViewport = true }

        card.addView(button("View details & report", accent, Color.WHITE) {
            dismiss(wm)
            c.startActivity(Intent(c, MainActivity::class.java).putExtra("open_id", q.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, 10) })
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        // Read aloud <-> Stop toggle (label flips back automatically when speech ends)
        val sayId = "overlay-${q.id}"
        lateinit var speakBtn: TextView
        speakBtn = button("🔊 Read aloud", Color.WHITE, ink) {
            if (Speaker.isSpeaking(sayId)) Speaker.stop()
            else {
                speakBtn.text = tr("⏹ Stop")
                Speaker.speak(c, sayId, spokenVerdict(q.verdict, q.score, q.reasons), spokenFallback(q.verdict, q.score)) {
                    speakBtn.text = tr("🔊 Read aloud")
                }
            }
        }
        row.addView(speakBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(c, 10) })
        row.addView(button("I understand", Color.WHITE, ink) { dismiss(wm) }, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row)

        val wrap = LinearLayout(c).apply {
            gravity = Gravity.CENTER; setPadding(dp(c, 18), dp(c, 40), dp(c, 18), dp(c, 40))
            addView(card, LinearLayout.LayoutParams(-1, -2))
        }
        root.addView(wrap, -1, -1)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
            PixelFormat.TRANSLUCENT,
        )
        wm.addView(root, lp)
        current = root
    }

    private fun dismiss(wm: WindowManager) {
        if (current != null) Speaker.stop() // closing the alert also stops the voice
        current?.let { runCatching { wm.removeView(it) } }
        current = null
    }
}
