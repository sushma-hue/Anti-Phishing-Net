"""Phishing Net validation server (FastAPI).

Run:  uvicorn app.main:app --reload --port 8000
Docs: http://localhost:8000/docs
"""
import time
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from . import analyzer, community, config, ml, sarvam, storage, url_checks, whatsapp

ml.load()  # trains on first start (~10 s), then loads from data/scam_model.joblib

app = FastAPI(title="Phishing Net", description="One forward. Zero fraud.", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
STATIC = Path(__file__).parent / "static"
from fastapi.staticfiles import StaticFiles
app.mount("/static", StaticFiles(directory=STATIC), name="static")


# ---------- models ----------
class CheckIn(BaseModel):
    text: str = Field(..., max_length=5000)
    source: str = "manual"          # manual | sms | notification | share | whatsapp
    user_id: str | None = None      # anonymous device id from the app
    reply_language: str | None = None


class ConsentIn(BaseModel):
    user_id: str
    scopes: list[str]               # e.g. ["sms", "notifications", "share"]
    granted: bool = True


class QuarantineIn(BaseModel):
    user_id: str
    verdict: str
    risk_score: int
    reasons: list[str]
    urls_found: list[str] = []
    status: str = "quarantined"     # quarantined | marked_safe | reported | removed


class ReportIn(BaseModel):
    user_id: str | None = None
    urls: list[str] = []
    phone: str | None = None
    category: str = "phishing"


# ---------- core ----------
def run_check(text: str, source: str, user_id: str | None, reply_lang: str | None = None, who: str = "") -> dict:
    who = user_id or who
    result = analyzer.analyze(text, source, who)
    # strong scams feed the community list (websites + phone numbers only, never the text)
    if result["verdict"] == "Phishing":
        for kind, key, display in community.indicators(text, result["urls_found"]):
            community.record(kind, key, display, who, result["flags"])
    lang = reply_lang or result["language"]
    # localize reasons for the user (one Sarvam call for all reasons)
    if lang != "en-IN":
        # one call per reason, in parallel (Sarvam merges lines if we join them)
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=8) as ex:
            result["reasons_localized"] = list(ex.map(lambda r: sarvam.localize(r, lang), result["reasons"]))
        result["verdict_localized"] = sarvam.localize(result["verdict"], lang)
    else:
        result["reasons_localized"] = result["reasons"]
        result["verdict_localized"] = result["verdict"]
    # Privacy: log only hashes + verdict, never the message text
    storage.put("checks", {
        "user_id": user_id, "source": source, "verdict": result["verdict"],
        "risk_score": result["risk_score"], "language": result["language"], "flags": result["flags"],
        "url_hashes": [storage.sha(u) for u in result["urls_found"]],
        "domains": [url_checks.registered_domain(u) for u in result["urls_found"]] if result["verdict"] != "Safe" else [],
    })
    return result


@app.post("/check")
def check(body: CheckIn, request: Request):
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "").split(",")[0]
    return run_check(body.text, body.source, body.user_id, body.reply_language, who=f"ip:{ip}")


# ---------- community scam list ----------
@app.get("/api/community")
def community_list(limit: int = 20):
    return {"items": community.top(min(limit, 100)), "summary": community.summary()}


@app.get("/api/lookup")
def lookup(q: str):
    """Check one website or phone number against the community list."""
    q = q.strip()[:300]
    found = community.indicators(q, url_checks.extract_urls(q))
    if not found:
        return {"found": False, "message": "Enter a website (e.g. sbi-kyc.xyz) or a 10-digit mobile number."}
    kind, key, display = found[0]
    e = community.lookup(key)
    if not e:
        return {"found": False, "kind": kind, "value": display,
                "message": "No reports yet. That doesn't mean it's safe — check the full message above."}
    return {"found": True, "kind": kind, "value": display, "people": community.people(e),
            "reports": e.get("reports", 0), "first": e["first"], "last": e["last"], "flags": e.get("flags", [])}


# ---------- ML model ----------
class FeedbackIn(BaseModel):
    text: str = Field(..., max_length=1000)
    is_scam: bool


@app.post("/api/feedback")
def feedback(body: FeedbackIn):
    """User says our verdict was wrong/right. Text stored ONLY because the user chose to send it."""
    ml.add_feedback(body.text, body.is_scam)
    return {"ok": True, "message": "Thanks! The model learns from this on the next retrain."}


@app.get("/api/model")
def model_info():
    return ml.info()


class ModelTestIn(BaseModel):
    text: str = Field(..., max_length=2000)


@app.post("/api/model/test")
def model_test(body: ModelTestIn):
    """The AI model alone (no rules, no link checks) — for the /model page."""
    p = ml.scam_probability(body.text)
    if p is None:
        raise HTTPException(503, "model not loaded")
    return {"probability": round(p, 4), "label": "scam" if p >= 0.5 else "normal", "normalized": ml.normalize(body.text)}


@app.get("/api/model/dataset.csv")
def model_dataset():
    import csv, io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["text", "label", "template"])
    w.writerows(ml.dataset_rows())
    return Response(content="﻿" + buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=phishing-net-dataset.csv"})


@app.get("/model")
def model_page():
    return FileResponse(STATIC / "model.html", headers={"Cache-Control": "no-cache"})


@app.get("/privacy")
def privacy_page():
    return FileResponse(STATIC / "privacy.html")


@app.post("/api/model/retrain")
def model_retrain(bg: BackgroundTasks):
    bg.add_task(ml.train)
    return {"ok": True, "message": "Retraining started"}


@app.get("/health")
def health():
    return {"status": "ok", "backends": storage.backends()}


class TranslateIn(BaseModel):
    texts: list[str] = Field(..., max_length=100)
    target: str = Field(..., max_length=10)


@app.post("/translate")
def translate_ui(body: TranslateIn):
    """App UI strings -> user's language via Sarvam (used when on-device translation lacks the language).
    Without a Sarvam key the texts come back unchanged (the app then keeps English)."""
    return {"texts": [sarvam.localize(t[:500], body.target) for t in body.texts]}


# ---------- WhatsApp (Method 1) ----------
@app.get("/webhook/whatsapp")
def wa_verify(request: Request):
    q = request.query_params
    if q.get("hub.mode") == "subscribe" and q.get("hub.verify_token") == config.WA_VERIFY_TOKEN:
        return Response(content=q.get("hub.challenge", ""), media_type="text/plain")
    raise HTTPException(403, "verification failed")


WA_HELLO = ("🛡️ *Phishing Net*\nForward me any suspicious SMS, WhatsApp message or link "
            "and I'll tell you if it's safe. Works in English, हिंदी, ಕನ್ನಡ, தமிழ் and more.")


def wa_reply_text(sender: str, text: str) -> str:
    """Bot reply for one incoming WhatsApp message (shared by Meta and Twilio)."""
    if text.strip().lower() in ("hi", "hello", "start", "help", "namaste"):
        return WA_HELLO
    result = run_check(text, "telegram" if sender.startswith("tg:") else "whatsapp", storage.sha(sender))
    header = result["verdict"]
    if result["language"] != "en-IN":
        header = f"{result['verdict_localized']} ({result['verdict']})"
    return whatsapp.format_reply(result, result["reasons_localized"], header)


def handle_wa_message(sender: str, text: str):
    whatsapp.send_text(sender, wa_reply_text(sender, text))


@app.post("/webhook/twilio")
async def twilio_incoming(request: Request):
    """Twilio WhatsApp Sandbox: form-encoded message in, TwiML reply out (no API key needed)."""
    from urllib.parse import parse_qs
    from xml.sax.saxutils import escape
    form = parse_qs((await request.body()).decode("utf-8"))
    sender = form.get("From", [""])[0]
    text = form.get("Body", [""])[0].strip()
    if text.lower().startswith("join "):
        reply = WA_HELLO
    elif text:
        reply = wa_reply_text(sender, text)
    else:
        reply = "Please send the message text (screenshots work in the Phishing Net app)."
    to_num = form.get("To", [""])[0]
    if config.TWILIO_SID and config.TWILIO_TOKEN and sender and to_num:
        # Twilio trial "Try it out" ignores TwiML replies, so send through the REST API instead
        import httpx
        r = httpx.post(f"https://api.twilio.com/2010-04-01/Accounts/{config.TWILIO_SID}/Messages.json",
                       auth=(config.TWILIO_SID, config.TWILIO_TOKEN),
                       data={"From": to_num, "To": sender, "Body": reply[:1500]}, timeout=15)
        if r.status_code >= 300:
            print(f"[twilio] send failed {r.status_code}: {r.text[:300]}")
        return Response(content='<?xml version="1.0" encoding="UTF-8"?><Response/>', media_type="application/xml")
    xml = f'<?xml version="1.0" encoding="UTF-8"?><Response><Message>{escape(reply)}</Message></Response>'
    return Response(content=xml, media_type="application/xml")


# ---------- Telegram bot ----------
def _tg_secret() -> str:
    import hashlib
    return hashlib.sha256(("tg:" + (config.TG_TOKEN or "")).encode()).hexdigest()[:32]


def _tg_send(chat_id, text: str):
    import httpx
    r = httpx.post(f"https://api.telegram.org/bot{config.TG_TOKEN}/sendMessage",
                   json={"chat_id": chat_id, "text": text[:4000], "disable_web_page_preview": True}, timeout=15)
    if r.status_code >= 300:
        print(f"[telegram] send failed {r.status_code}: {r.text[:300]}")


def handle_tg_message(chat_id, text: str):
    if text.startswith("/start") or text.strip().lower() in ("hi", "hello", "help", "/help", "namaste"):
        reply = WA_HELLO
    else:
        reply = wa_reply_text(f"tg:{chat_id}", text)
    _tg_send(chat_id, reply.replace("*", ""))


@app.post("/webhook/telegram")
async def tg_incoming(request: Request, bg: BackgroundTasks):
    if not config.TG_TOKEN or request.headers.get("x-telegram-bot-api-secret-token") != _tg_secret():
        raise HTTPException(403, "forbidden")
    upd = await request.json()
    msg = upd.get("message") or upd.get("edited_message") or {}
    text = (msg.get("text") or msg.get("caption") or "").strip()
    chat_id = msg.get("chat", {}).get("id")
    if chat_id and text:
        bg.add_task(handle_tg_message, chat_id, text)
    elif chat_id:
        bg.add_task(_tg_send, chat_id, "Please send the message as text (or a photo with the text as caption).")
    return {"ok": True}


@app.get("/api/telegram/setup")
def tg_setup(request: Request):
    """Points the Telegram bot at this server. Safe to call again; the token never leaves the server."""
    if not config.TG_TOKEN:
        raise HTTPException(400, "TELEGRAM_BOT_TOKEN not set")
    import httpx
    url = f"https://{request.headers.get('host')}/webhook/telegram"
    r = httpx.post(f"https://api.telegram.org/bot{config.TG_TOKEN}/setWebhook",
                   json={"url": url, "secret_token": _tg_secret(), "allowed_updates": ["message", "edited_message"]}, timeout=15)
    me = httpx.get(f"https://api.telegram.org/bot{config.TG_TOKEN}/getMe", timeout=15).json().get("result", {})
    return {"webhook": url, "telegram": r.json(), "bot": "@" + me.get("username", "?")}


@app.post("/webhook/whatsapp")
async def wa_incoming(request: Request, bg: BackgroundTasks):
    payload = await request.json()
    msgs = whatsapp.parse_incoming(payload)
    print(f"[whatsapp] webhook: {len(msgs)} message(s)")
    for sender, text in msgs:
        bg.add_task(handle_wa_message, sender, text)  # reply async; Meta needs a fast 200
    return {"ok": True}


# ---------- App sync / privacy (DPDP) ----------
@app.post("/consent")
def consent(body: ConsentIn):
    doc_id = storage.put("consents", {**body.model_dump(), "ts": time.time()})
    return {"ok": True, "consent_id": doc_id}


@app.post("/quarantine")
def quarantine(body: QuarantineIn):
    # Only verdict metadata + URL hashes are synced, never the message body
    data = body.model_dump()
    data["url_hashes"] = [storage.sha(u) for u in data.pop("urls_found")]
    return {"ok": True, "id": storage.put("quarantine", data)}


@app.post("/report")
def report(body: ReportIn):
    hashes = [storage.add_scam_indicator(url_checks.registered_domain(u)) for u in body.urls]
    if body.phone:
        hashes.append(storage.add_scam_indicator(body.phone, "phone"))
    for kind, key, display in community.indicators(body.phone or "", body.urls):
        community.record(kind, key, display, body.user_id or "anon", reported=True)
    storage.put("reports", {"user_id": body.user_id, "category": body.category, "hashes": hashes,
                            "domains": [url_checks.registered_domain(u) for u in body.urls]})
    return {"ok": True, "helpline": "1930", "portal": "https://cybercrime.gov.in"}


@app.delete("/user/{user_id}")
def delete_user(user_id: str):
    """Consent withdrawal + right to erasure."""
    return {"ok": True, "deleted_records": storage.delete_user(user_id)}


# ---------- Dashboard ----------
@app.get("/api/stats")
def stats():
    checks = storage.recent("checks", 500)
    by = {"Safe": 0, "Suspicious": 0, "Phishing": 0}
    for c in checks:
        by[c["verdict"]] = by.get(c["verdict"], 0) + 1
    # public endpoint: strip anything that could identify a device/user
    hide = {"user_id", "id", "url_hashes"}
    clean = lambda rows: [{k: v for k, v in r.items() if k not in hide} for r in rows]
    return {"total": len(checks), "by_verdict": by, "recent": clean(checks[:25]),
            "reports": clean(storage.recent("reports", 25)), "backends": storage.backends(),
            "model": ml.info(), "community": community.summary()}


@app.get("/")
def website():
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/download")
def download_apk():
    if config.APK_URL:
        from fastapi.responses import RedirectResponse
        return RedirectResponse(config.APK_URL)
    return FileResponse(STATIC / "phishing-net.apk", media_type="application/vnd.android.package-archive",
                        filename="PhishingNet.apk")


@app.get("/dashboard")
def dashboard():
    return FileResponse(STATIC / "dashboard.html", headers={"Cache-Control": "no-cache"})
