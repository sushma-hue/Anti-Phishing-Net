"""Central config: every key comes from .env. Missing keys = feature skipped gracefully."""
import os
from dotenv import load_dotenv

load_dotenv()


def env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


SARVAM_API_KEY = env("SARVAM_API_KEY")
SAFE_BROWSING_KEY = env("GOOGLE_SAFE_BROWSING_KEY")

# Firebase: path to service-account JSON
FIREBASE_CREDENTIALS = env("FIREBASE_CREDENTIALS")
FIREBASE_CREDENTIALS_JSON = env("FIREBASE_CREDENTIALS_JSON")  # for hosting: paste the file's contents

# Where the website's "Download APK" button points (e.g. a GitHub Release asset)
APK_URL = env("APK_URL")

# Meta WhatsApp Cloud API
TG_TOKEN = env("TELEGRAM_BOT_TOKEN")
WA_TOKEN = env("WHATSAPP_TOKEN")
WA_PHONE_ID = env("WHATSAPP_PHONE_NUMBER_ID")
WA_VERIFY_TOKEN = env("WHATSAPP_VERIFY_TOKEN", "phishingnet-verify")
TWILIO_SID = env("TWILIO_ACCOUNT_SID")
TWILIO_TOKEN = env("TWILIO_AUTH_TOKEN")

# Zoho Catalyst (shared scam-indicator database)
ZOHO_CLIENT_ID = env("ZOHO_CLIENT_ID")
ZOHO_CLIENT_SECRET = env("ZOHO_CLIENT_SECRET")
ZOHO_REFRESH_TOKEN = env("ZOHO_REFRESH_TOKEN")
CATALYST_PROJECT_ID = env("CATALYST_PROJECT_ID")
CATALYST_TABLE = env("CATALYST_TABLE", "ScamIndicators")
ZOHO_ACCOUNTS_URL = env("ZOHO_ACCOUNTS_URL", "https://accounts.zoho.in")
CATALYST_API_URL = env("CATALYST_API_URL", "https://api.catalyst.zoho.in")

# Set CHECK_NETWORK=0 to skip all live lookups (WHOIS, redirects, SSL). Tests do this.
CHECK_NETWORK = env("CHECK_NETWORK", "1") != "0"
