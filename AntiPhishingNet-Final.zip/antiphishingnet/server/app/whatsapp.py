"""Meta WhatsApp Cloud API: parse incoming webhook + send replies."""
import httpx

from . import config

GRAPH = "https://graph.facebook.com/v21.0"
EMOJI = {"Safe": "✅", "Suspicious": "⚠️", "Phishing": "🚨"}


def parse_incoming(payload: dict) -> list[tuple[str, str]]:
    """Return [(sender_phone, text)] from a webhook payload. Ignores status updates."""
    out = []
    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            for st in change.get("value", {}).get("statuses", []):
                print(f"[whatsapp] status {st.get('status')} errors={st.get('errors')}")
            for msg in change.get("value", {}).get("messages", []):
                text = ""
                if msg.get("type") == "text":
                    text = msg["text"]["body"]
                elif msg.get("type") in ("image", "video", "document"):
                    text = msg[msg["type"]].get("caption", "")
                if text:
                    out.append((msg["from"], text))
    return out


def format_reply(result: dict, reasons: list[str], header: str) -> str:
    lines = [f"{EMOJI[result['verdict']]} *{header}*", f"Risk score: *{result['risk_score']}/100*", ""]
    lines += [f"• {r}" for r in reasons[:5]]
    if result["verdict"] != "Safe":
        lines += ["", "Do NOT click links, share OTP or pay. Lost money? Call *1930* or visit cybercrime.gov.in"]
    lines += ["", "— Phishing Net 🛡️ One forward. Zero fraud."]
    return "\n".join(lines)


def send_text(to: str, body: str) -> bool:
    if not (config.WA_TOKEN and config.WA_PHONE_ID):
        print(f"[whatsapp] (not configured) would send to {to}:\n{body}")
        return False
    r = httpx.post(
        f"{GRAPH}/{config.WA_PHONE_ID}/messages",
        headers={"Authorization": f"Bearer {config.WA_TOKEN}"},
        json={"messaging_product": "whatsapp", "to": to, "type": "text", "text": {"body": body}},
        timeout=10,
    )
    print(f"[whatsapp] send -> {r.status_code}: {r.text[:300]}")
    return r.status_code < 300
