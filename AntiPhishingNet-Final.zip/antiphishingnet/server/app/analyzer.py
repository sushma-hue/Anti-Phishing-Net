"""The core phishing analyzer: text in -> verdict, score, reasons out.

Score = sum of points from every flag (capped at 100).
  0-40 Safe | 41-70 Suspicious | 71-100 Phishing
Each flag has an id so the same signal (e.g. found in both the original Kannada
text and its English translation) is only counted once.
"""
import re

from . import community, ml, sarvam, storage, url_checks

# (flag_id, points, regex, reason). Applied to English text (original or translated).
EN_RULES = [
    ("kyc", 20, r"\bkyc\b|\bpan\b.*\b(link|update)|aadhaar.*(update|link)", "Asks you to update KYC / PAN / Aadhaar"),
    ("urgent", 15, r"urgent|immediately|\bnow\b|today|tonight|within \d+ ?(hours?|hrs|minutes?)|expire|last (date|chance|warning)",
     "Creates urgency to make you act without thinking"),
    ("blocked", 20, r"block|suspend|deactivat|freez|clos(e|ed) your|disabled", "Threatens to block or suspend your account"),
    ("reward", 25, r"prize|lottery|won\b|winner|reward|cashback|gift|lucky draw|free (iphone|recharge)",
     "Promises a prize, reward or cashback"),
    ("refund", 15, r"refund|tax return|claim (your|the)", "Talks about a refund you did not request"),
    ("click", 15, r"click (here|below|the link)|tap (here|the link)|visit the link|open the link", "Pushes you to click a link"),
    ("electricity", 40, r"electricity|power (supply|connection)|\bbill\b.*(not paid|unpaid|pending)|disconnect",
     "Electricity disconnection threat - a very common scam"),
    ("parcel", 40, r"parcel|courier|package|shipment|delivery", "Fake courier / parcel scam pattern"),
    ("credentials", 30, r"(share|send|enter|confirm).{0,20}(otp|pin|cvv|password|card number)",
     "Asks for your OTP, PIN, CVV or password"),
    ("small_fee", 20, r"(rs\.?|inr|₹)\s?\d{1,3}\b.{0,30}(pay|fee|charge)|pay.{0,20}(rs\.?|inr|₹)\s?\d{1,3}\b",
     "Asks for a small payment - typical of scams"),
    ("call_number", 20, r"call\s*(on|us|at)?\s*[+\d][\dx\- ]{8,}", "Asks you to call an unknown phone number"),
    ("upi", 40, r"(enter|use|type|put).{0,20}\bpin\b.{0,40}(receive|get|refund|credit|claim)"
                r"|(receive|get|refund|credit|claim).{0,40}(enter|use|type|put).{0,20}\bpin\b"
                r"|approve.{0,30}(request|collect)|(request|collect).{0,30}approve",
     "Asks you to enter your UPI PIN or approve a request to receive money - a UPI PIN only ever sends money"),
    ("wrong_payment", 35, r"(sent|transferred|paid|credited).{0,40}by mistake|wrong(ly)? (sent|transferred|credited)"
                          r"|mistakenly (sent|transferred|credited)|please (return|send back|refund) (it|the money|my money)",
     "Claims money was sent to you by mistake and asks for it back - a common UPI scam"),
]

# upi://pay links (QR codes or pasted): who really gets the money, and what it pretends to be
UPI_LINK = re.compile(r"upi://pay\?[^\s<>\"']+", re.I)
UPI_BAIT = re.compile(r"refund|cash ?back|prize|reward|lottery|winner|kyc|support|help|care|desk|claim|bonus|gift", re.I)
UPI_BRANDS = ["amazon", "flipkart", "paytm", "phonepe", "google pay", "gpay", "sbi", "hdfc", "icici", "axis",
              "irctc", "airtel", "jio", "bescom", "electricity", "income tax", "rbi", "npci"]

# Regional-language keywords matched on the ORIGINAL text (works even without Sarvam)
REGIONAL_RULES = [
    ("kyc", 20, r"केवाईसी|ಕೆವೈಸಿ|கேஒய்சி", "Asks you to update KYC"),
    ("blocked", 20, r"बंद|ब्लॉक|ನಿರ್ಬಂಧ|ಬ್ಲಾಕ್|ಸ್ಥಗಿತ", "Threatens to block your account"),
    ("electricity", 40, r"बिजली|ವಿದ್ಯುತ್|ಕರೆಂಟ್|மின்", "Electricity disconnection threat"),
    ("parcel", 40, r"पार्सल|कूरियर|ಪಾರ್ಸೆಲ್|ಕೊರಿಯರ್|பார்சல்", "Fake courier / parcel scam pattern"),
    ("reward", 25, r"इनाम|लॉटरी|ಬಹುಮಾನ|ಲಾಟರಿ", "Promises a prize or lottery"),
    ("urgent", 15, r"तुरंत|अभी|ತಕ್ಷಣ|ಈಗಲೇ|இப்போதே", "Creates urgency"),
    ("small_fee", 20, r"₹\s?\d{1,3}\b", "Asks for a small payment - typical of scams"),
    ("pay_demand", 15, r"कट्ट|भुगतान|ಕಟ್ಟಿ|ಪಾವತಿ|செலுத்த", "Demands that you pay money"),
]

# Signals that a message is a genuine, informational bank/OTP message
SAFE_HINTS = re.compile(r"do not share|don't share|never share|never ask|will never call", re.I)


def verdict_for(score: int) -> str:
    return "Safe" if score <= 40 else "Suspicious" if score <= 70 else "Phishing"


def analyze(text: str, source: str = "manual", who: str = "") -> dict:
    english, lang = sarvam.to_english(text)
    flags: dict[str, tuple[int, str]] = {}

    def add(fid, pts, reason):
        if fid not in flags:
            flags[fid] = (pts, reason)

    # 1. keyword rules on english + regional rules on original
    for fid, pts, pat, reason in EN_RULES:
        if re.search(pat, english, re.I) or (english != text and re.search(pat, text, re.I)):
            add(fid, pts, reason)
    for fid, pts, pat, reason in REGIONAL_RULES:
        if re.search(pat, text):
            add(fid, pts, reason)

    # 2. URL checks
    urls = url_checks.extract_urls(text)
    for u in urls:
        for fid, pts, reason in url_checks.check_url(u):
            add(fid, pts, reason)
        if storage.is_known_scam(url_checks.registered_domain(u)) or storage.is_known_scam(u):
            add("known_scam", 60, "This link is in our reported-scam database")

    # UPI payment links: scanning or tapping one always SENDS money, never receives it
    from urllib.parse import parse_qs, unquote_plus, urlsplit
    for link in UPI_LINK.findall(text):
        q = {k.lower(): unquote_plus(v[0]) for k, v in parse_qs(urlsplit(link).query).items()}
        pa, pn = q.get("pa", ""), q.get("pn", "")
        if UPI_BAIT.search(pa) or UPI_BAIT.search(pn):
            add("upi_bait", 45, "This UPI payment link pretends to be a refund or reward - paying it sends your money to the scammer")
        brand = next((b for b in UPI_BRANDS if b in pn.lower()), None)
        if brand and pa:
            add("brand_mismatch", 20, f"Payment link uses the name {brand.title()} but pays a personal UPI ID ({pa})")

    # brand mentioned in text + a link that is NOT that brand's official site
    for brand, domains in url_checks.BRANDS.items():
        if re.search(rf"\b{brand}\b", english, re.I) and urls and not any(
                url_checks.registered_domain(u) in domains for u in urls):
            add("brand_mismatch", 20, f"Mentions {brand.upper()} but the link is not {brand.upper()}'s official website")
            break

    flagged = url_checks.safe_browsing(urls)
    if flagged:
        add("safe_browsing", 100, "Google Safe Browsing lists this link as dangerous")

    # 3. community scam list: has anyone else met this website / number in a scam?
    me = storage.sha(who or "anon")[:16]
    for kind, key, display in community.indicators(text, urls):
        e = community.lookup(key)
        if not e:
            continue
        others = len([p for p in e.get("people", []) if p != me])
        if e.get("reports", 0) or others >= 1:
            n = max(others, e.get("reports", 0))
            what = "website" if kind == "website" else "phone number"
            add("community", 35 if n >= 2 else 25,
                f"This {what} ({display}) was flagged in scams by {n} other Phishing Net user{'s' if n != 1 else ''}")

    # 4. ML model: probability learned from thousands of Indian scam / normal messages
    p = ml.scam_probability(text)
    if english != text:
        p2 = ml.scam_probability(english)
        p = max(p or 0, p2 or 0)

    # 5. score
    score = sum(pt for pt, _ in flags.values())
    if p is not None and p >= 0.8:
        add("ml", 0, f"AI model: {round(p * 100)}% likely a scam based on its wording")
        score += min(40, round((p - 0.5) * 100))  # 0.8 -> +30, 0.9+ -> +40
    elif p is not None and p <= 0.15 and not urls:
        score -= 10  # model is confident this reads like a normal message
    if SAFE_HINTS.search(english) and not urls:
        score -= 25  # genuine OTP/alert messages usually warn you not to share
    score = max(0, min(100, score))

    return {
        "verdict": verdict_for(score),
        "risk_score": score,
        "reasons": [r for _, r in flags.values()] or ["No phishing signals found"],
        "flags": list(flags.keys()),
        "urls_found": urls,
        "language": lang,
        "translated_text": english if english != text else None,
        "source": source,
        "ml_probability": round(p, 3) if p is not None else None,
    }
