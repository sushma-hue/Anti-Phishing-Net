"""Sarvam AI helpers: language detection + translation.

If SARVAM_API_KEY is missing or the API fails, we fall back to a Unicode-script
based language guess and skip translation (regional keyword lists still work).
"""
import httpx
from . import config

BASE = "https://api.sarvam.ai"

# Unicode block -> Sarvam language code (used as offline fallback)
SCRIPT_RANGES = [
    (0x0900, 0x097F, "hi-IN"),  # Devanagari (Hindi/Marathi)
    (0x0980, 0x09FF, "bn-IN"),  # Bengali
    (0x0A00, 0x0A7F, "pa-IN"),  # Gurmukhi
    (0x0A80, 0x0AFF, "gu-IN"),  # Gujarati
    (0x0B00, 0x0B7F, "od-IN"),  # Odia
    (0x0B80, 0x0BFF, "ta-IN"),  # Tamil
    (0x0C00, 0x0C7F, "te-IN"),  # Telugu
    (0x0C80, 0x0CFF, "kn-IN"),  # Kannada
    (0x0D00, 0x0D7F, "ml-IN"),  # Malayalam
]


def guess_language(text: str) -> str:
    counts: dict[str, int] = {}
    for ch in text:
        cp = ord(ch)
        for lo, hi, code in SCRIPT_RANGES:
            if lo <= cp <= hi:
                counts[code] = counts.get(code, 0) + 1
    return max(counts, key=counts.get) if counts else "en-IN"


def _headers():
    return {"api-subscription-key": config.SARVAM_API_KEY, "Content-Type": "application/json"}


def translate(text: str, source: str = "auto", target: str = "en-IN") -> tuple[str, str]:
    """Return (translated_text, detected_source_language). Falls back to (text, guess)."""
    guess = guess_language(text)
    if not config.SARVAM_API_KEY or not text.strip():
        return text, guess
    if source == target or (source == "auto" and guess == target):
        return text, guess
    try:
        r = httpx.post(
            f"{BASE}/translate",
            headers=_headers(),
            json={
                "input": text[:1000],
                "source_language_code": source,
                "target_language_code": target,
                "mode": "formal",
            },
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
        return data.get("translated_text", text), data.get("source_language_code", guess)
    except Exception as e:  # never break the pipeline because of translation
        print(f"[sarvam] translate failed: {e}")
        return text, guess


def to_english(text: str) -> tuple[str, str]:
    """Detect language and translate to English. Returns (english_text, language_code)."""
    lang = guess_language(text)
    if lang == "en-IN":
        return text, "en-IN"
    english, detected = translate(text, "auto", "en-IN")
    return english, detected or lang


_CACHE_FILE = None
_cache: dict | None = None


def _load_cache() -> dict:
    global _cache, _CACHE_FILE
    if _cache is None:
        import json
        from pathlib import Path
        _CACHE_FILE = Path(__file__).parent.parent / "data" / "translation_cache.json"
        try:
            _cache = json.loads(_CACHE_FILE.read_text(encoding="utf-8"))
        except Exception:
            _cache = {}
    return _cache


def localize(text: str, lang: str) -> str:
    """Translate an English reply line into the user's language.
    1) built-in phrasebook (offline, free)  2) saved earlier translations  3) Sarvam (then saved)."""
    if lang in ("en-IN", "", None):
        return text
    from . import phrasebook
    hit = phrasebook.lookup(text, lang)
    if hit:
        return hit
    cache = _load_cache()
    key = f"{lang}|{text}"
    if key in cache:
        return cache[key]
    out, _ = translate(text, "en-IN", lang)
    if out and out != text:  # only remember real translations
        import json
        cache[key] = out
        try:
            _CACHE_FILE.parent.mkdir(exist_ok=True)
            _CACHE_FILE.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            print(f"[sarvam] cache save failed: {e}")
    return out
