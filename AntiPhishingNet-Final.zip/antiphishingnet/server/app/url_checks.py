"""URL / domain checks. Each check returns a list of (flag_id, points, reason)."""
import ipaddress
import re
import socket
import ssl
from datetime import datetime, timezone
from urllib.parse import urlparse

import httpx
import tldextract

from . import config

# Offline public-suffix list (no network call at import time)
_extract = tldextract.TLDExtract(suffix_list_urls=())

URL_RE = re.compile(
    r"((?:https?://)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?::\d+)?(?:/[^\s]*)?|https?://\d{1,3}(?:\.\d{1,3}){3}[^\s]*)",
    re.IGNORECASE,
)

SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy",
              "ow.ly", "shorturl.at", "tiny.cc", "rebrand.ly", "s.id", "t.ly"}

SUSPICIOUS_TLDS = {"xyz", "top", "shop", "info", "click", "link", "online", "site", "live",
                   "buzz", "icu", "rest", "fit", "work", "loan", "win", "vip", "cyou", "sbs", "cfd"}

# Real brands -> their official registered domains
BRANDS = {
    "sbi": ["sbi.co.in", "onlinesbi.sbi", "sbi.bank.in"],
    "hdfc": ["hdfcbank.com", "hdfc.com"],
    "icici": ["icicibank.com"],
    "axis": ["axisbank.com"],
    "kotak": ["kotak.com"],
    "paytm": ["paytm.com"],
    "phonepe": ["phonepe.com"],
    "gpay": ["pay.google.com"],
    "amazon": ["amazon.in", "amazon.com"],
    "flipkart": ["flipkart.com"],
    "indiapost": ["indiapost.gov.in"],
    "bescom": ["bescom.co.in"],
    "incometax": ["incometax.gov.in"],
    "uidai": ["uidai.gov.in"],
    "npci": ["npci.org.in"],
    "irctc": ["irctc.co.in"],
    "bluedart": ["bluedart.com"],
    "delhivery": ["delhivery.com"],
}
OFFICIAL_DOMAINS = {d for ds in BRANDS.values() for d in ds}

# Look-alike character tricks: 0->o, 1->l, rn->m, vv->w ...
HOMOGLYPHS = [("rn", "m"), ("vv", "w"), ("0", "o"), ("1", "l"), ("3", "e"),
              ("4", "a"), ("5", "s"), ("7", "t"), ("@", "a"), ("$", "s")]


def extract_urls(text: str) -> list[str]:
    found = []
    for m in URL_RE.findall(text):
        url = m.rstrip(".,)!?'\"")
        # skip things like "5.30pm" or "Rs.50"
        if not re.search(r"[a-z]", _extract(url).suffix or ""):
            continue
        if not url.lower().startswith("http"):
            url = "http://" + url
        if url not in found:
            found.append(url)
    return found


def registered_domain(url: str) -> str:
    ext = _extract(urlparse(url).hostname or "")
    return f"{ext.domain}.{ext.suffix}" if ext.suffix else ext.domain


def normalize(s: str) -> str:
    s = s.lower()
    for a, b in HOMOGLYPHS:
        s = s.replace(a, b)
    return s


def levenshtein(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def lookalike_brand(url: str) -> str | None:
    """Return the brand a non-official domain is imitating, else None."""
    host = (urlparse(url).hostname or "").lower()
    reg = registered_domain(url)
    if reg in OFFICIAL_DOMAINS or any(host.endswith("." + d) for d in OFFICIAL_DOMAINS):
        return None
    tokens = re.split(r"[.\-_]", host)
    for tok in tokens:
        n = normalize(tok)
        for brand in BRANDS:
            if len(brand) < 3:
                continue
            if n == brand or brand in n:  # exact or embedded (e.g. sbi-kyc, amaz0nsale)
                return brand
            if len(brand) >= 5 and levenshtein(n, brand) <= 1:  # typo (e.g. flipkrt)
                return brand
    return None


# ---------- network checks (skipped when CHECK_NETWORK=0) ----------

def unwrap(url: str) -> tuple[str, list[str]]:
    """Follow redirects (shorteners). Returns (final_url, chain)."""
    if not config.CHECK_NETWORK:
        return url, [url]
    try:
        with httpx.Client(follow_redirects=True, timeout=5, verify=False,
                          headers={"User-Agent": "Mozilla/5.0 PhishingNet"}) as c:
            r = c.head(url)
            if r.status_code >= 400:
                r = c.get(url)
            chain = [str(h.url) for h in r.history] + [str(r.url)]
            return str(r.url), chain
    except Exception:
        return url, [url]


def domain_age_days(domain: str) -> int | None:
    if not config.CHECK_NETWORK:
        return None
    try:
        import whois
        created = whois.whois(domain).creation_date
        if isinstance(created, list):
            created = min(created)
        if not created:
            return None
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - created).days
    except Exception:
        return None


def ssl_valid(host: str) -> bool | None:
    if not config.CHECK_NETWORK:
        return None
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, 443), timeout=4) as sock:
            with ctx.wrap_socket(sock, server_hostname=host):
                return True
    except ssl.SSLError:
        return False
    except Exception:
        return None  # unreachable: unknown, don't penalise


def safe_browsing(urls: list[str]) -> set[str]:
    """Return the subset of urls Google Safe Browsing flags."""
    if not config.SAFE_BROWSING_KEY or not urls or not config.CHECK_NETWORK:
        return set()
    try:
        r = httpx.post(
            f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={config.SAFE_BROWSING_KEY}",
            json={
                "client": {"clientId": "phishingnet", "clientVersion": "1.0"},
                "threatInfo": {
                    "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE"],
                    "platformTypes": ["ANY_PLATFORM"],
                    "threatEntryTypes": ["URL"],
                    "threatEntries": [{"url": u} for u in urls],
                },
            },
            timeout=6,
        )
        return {m["threat"]["url"] for m in r.json().get("matches", [])}
    except Exception as e:
        print(f"[safebrowsing] {e}")
        return set()


def check_url(url: str) -> list[tuple[str, int, str]]:
    """Run every per-URL check. Returns flags (id, points, english reason)."""
    flags = []
    p = urlparse(url)
    host = (p.hostname or "").lower()
    reg = registered_domain(url)

    if reg in SHORTENERS:
        flags.append(("shortener", 20, f"Uses a link shortener ({reg}) that hides the real website"))
        final, chain = unwrap(url)
        if final != url and registered_domain(final) not in SHORTENERS:
            flags.append(("redirect", 5, f"Link redirects to {registered_domain(final)}"))
            url, p, host, reg = final, urlparse(final), (urlparse(final).hostname or "").lower(), registered_domain(final)

    if reg in OFFICIAL_DOMAINS or any(host.endswith("." + d) for d in OFFICIAL_DOMAINS):
        return flags  # genuine official site; nothing more to flag

    try:
        ipaddress.ip_address(host)
        flags.append(("ip_url", 30, "Link uses a raw IP address instead of a website name"))
    except ValueError:
        pass
    if "@" in p.netloc:
        flags.append(("at_trick", 30, "Link uses the '@' trick to disguise the real destination"))

    brand = lookalike_brand(url)
    if brand:
        flags.append(("lookalike", 45, f"Website '{host}' imitates {brand.upper()} but is not its official site"))

    tld = _extract(host).suffix.split(".")[-1]
    if tld in SUSPICIOUS_TLDS:
        flags.append(("bad_tld", 20, f"Uses a cheap domain ending '.{tld}' common in scams"))

    if p.scheme != "https":
        flags.append(("no_https", 10, "Link is not secure (no HTTPS)"))
    elif ssl_valid(host) is False:
        flags.append(("bad_ssl", 20, "Website's security certificate is invalid"))

    age = domain_age_days(reg)
    if age is not None and age < 30:
        flags.append(("new_domain", 40, f"Website was registered only {age} days ago"))
    elif age is not None and age < 180:
        flags.append(("young_domain", 20, f"Website is very new ({age} days old)"))
    return flags
