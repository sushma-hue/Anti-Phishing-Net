"""Persistence layer.

- Firebase Firestore: check logs (hashes only), consent records, quarantine sync, reports.
- Zoho Catalyst Data Store: shared known-scam indicator DB (SHA-256 of URLs/domains/phones).
Both fall back to in-memory storage when credentials are missing, so the demo always runs.
"""
import hashlib
import time
import uuid

import httpx

from . import config


def sha(value: str) -> str:
    return hashlib.sha256(value.strip().lower().encode()).hexdigest()


# ---------------- Firestore ----------------
_db = None
_memory: dict[str, dict[str, dict]] = {}

if config.FIREBASE_CREDENTIALS or config.FIREBASE_CREDENTIALS_JSON:
    try:
        import json as _json
        import firebase_admin
        from firebase_admin import credentials, firestore
        # hosting: whole JSON in an env var; local: path to the file
        cert = _json.loads(config.FIREBASE_CREDENTIALS_JSON) if config.FIREBASE_CREDENTIALS_JSON else config.FIREBASE_CREDENTIALS
        firebase_admin.initialize_app(credentials.Certificate(cert))
        _db = firestore.client()
        print("[storage] Firestore connected")
    except Exception as e:
        print(f"[storage] Firestore disabled: {e}")


# Firestore's free plan allows 50k reads/day and the dashboards poll every few seconds,
# so reads are cached: new records are kept in memory too and merged in, and Firestore
# itself is re-read at most once per CACHE_TTL. A Firestore error never breaks a request.
CACHE_TTL = 3600
MEMORY_CAP = 1000
_cache: dict[tuple, tuple[float, list[dict]]] = {}


def put(collection: str, doc: dict, doc_id: str | None = None) -> str:
    doc_id = doc_id or uuid.uuid4().hex
    doc = {**doc, "ts": doc.get("ts", time.time())}
    mem = _memory.setdefault(collection, {})
    mem[doc_id] = doc
    if len(mem) > MEMORY_CAP:  # keep only the newest
        for k in sorted(mem, key=lambda k: mem[k]["ts"])[:len(mem) - MEMORY_CAP]:
            del mem[k]
    if _db:
        try:
            _db.collection(collection).document(doc_id).set(doc)
        except Exception as e:
            print(f"[storage] Firestore write failed ({collection}): {e}")
    return doc_id


def recent(collection: str, limit: int = 50) -> list[dict]:
    docs = [{"id": k, **v} for k, v in _memory.get(collection, {}).items()]
    if _db:
        key = (collection, limit)
        hit = _cache.get(key)
        if not hit or time.time() - hit[0] > CACHE_TTL:
            try:
                from firebase_admin import firestore
                q = _db.collection(collection).order_by("ts", direction=firestore.Query.DESCENDING).limit(limit)
                hit = (time.time(), [{"id": d.id, **d.to_dict()} for d in q.stream()])
            except Exception as e:
                print(f"[storage] Firestore read failed ({collection}): {e}")
                hit = (time.time() - CACHE_TTL + 300, hit[1] if hit else [])  # retry in 5 min
            _cache[key] = hit
        seen = {d["id"] for d in docs}
        docs += [d for d in hit[1] if d["id"] not in seen]
    return sorted(docs, key=lambda d: d.get("ts", 0), reverse=True)[:limit]


def delete_user(user_id: str) -> int:
    """DPDP right to erasure: delete every record belonging to a user."""
    n = 0
    for col in ("consents", "quarantine", "checks", "reports"):
        docs = _memory.get(col, {})
        mine = [k for k, v in docs.items() if v.get("user_id") == user_id]
        for k in mine:
            del docs[k]
        if _db:
            for d in _db.collection(col).where("user_id", "==", user_id).stream():
                d.reference.delete()
                n += 1
        else:
            n += len(mine)
    _cache.clear()
    return n


# ---------------- Zoho Catalyst (scam indicator DB) ----------------
_known_scams: set[str] = set()  # local cache of hashes
_zoho_token = {"value": "", "exp": 0.0}


def _zoho_enabled() -> bool:
    return all([config.ZOHO_CLIENT_ID, config.ZOHO_CLIENT_SECRET,
                config.ZOHO_REFRESH_TOKEN, config.CATALYST_PROJECT_ID])


def _zoho_access_token() -> str:
    if time.time() < _zoho_token["exp"]:
        return _zoho_token["value"]
    r = httpx.post(f"{config.ZOHO_ACCOUNTS_URL}/oauth/v2/token", params={
        "refresh_token": config.ZOHO_REFRESH_TOKEN, "client_id": config.ZOHO_CLIENT_ID,
        "client_secret": config.ZOHO_CLIENT_SECRET, "grant_type": "refresh_token"}, timeout=10)
    data = r.json()
    _zoho_token.update(value=data["access_token"], exp=time.time() + data.get("expires_in", 3600) - 60)
    return _zoho_token["value"]


def _catalyst(method: str, path: str, **kw):
    url = f"{config.CATALYST_API_URL}/baas/v1/project/{config.CATALYST_PROJECT_ID}{path}"
    headers = {"Authorization": f"Zoho-oauthtoken {_zoho_access_token()}"}
    return httpx.request(method, url, headers=headers, timeout=8, **kw)


def is_known_scam(indicator: str) -> bool:
    h = sha(indicator)
    if h in _known_scams:
        return True
    if _zoho_enabled() and config.CHECK_NETWORK:
        try:
            r = _catalyst("POST", "/query", json={
                "query": f"SELECT ROWID FROM {config.CATALYST_TABLE} WHERE hash = '{h}'"})
            body = r.json()
            if r.status_code == 200 and body.get("status") == "success" and isinstance(body.get("data"), list) and body["data"]:
                _known_scams.add(h)
                return True
        except Exception as e:
            print(f"[zoho] lookup failed: {e}")
    return False


def add_scam_indicator(indicator: str, kind: str = "url") -> str:
    """Add an indicator hash to the shared scam DB (Zoho Catalyst + local cache)."""
    h = sha(indicator)
    _known_scams.add(h)
    if _zoho_enabled():
        try:
            _catalyst("POST", f"/table/{config.CATALYST_TABLE}/row",
                      json=[{"hash": h, "kind": kind, "reported_at": int(time.time())}])
        except Exception as e:
            print(f"[zoho] insert failed: {e}")
    return h


def backends() -> dict:
    return {"firestore": bool(_db), "zoho_catalyst": _zoho_enabled(),
            "sarvam": bool(config.SARVAM_API_KEY), "safe_browsing": bool(config.SAFE_BROWSING_KEY),
            "telegram": bool(config.TG_TOKEN)}
