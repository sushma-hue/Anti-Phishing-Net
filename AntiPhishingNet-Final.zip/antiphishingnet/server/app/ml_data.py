"""Training examples for the scam-text model.

Built from real Indian scam patterns (bank KYC, electricity, parcel, lottery, job/task, UPI refund,
digital arrest, loan, crypto) and real normal traffic (OTPs, bank alerts, deliveries, chats, offers).
Templates are filled with random values so the model learns the *shape* of a scam, not exact wording.
User feedback from the website (data/feedback.jsonl) is added on top of this every time we retrain.
"""
import random

BANKS = ["SBI", "HDFC", "ICICI", "Axis", "Kotak", "PNB", "Bank of Baroda", "Canara Bank", "Yes Bank", "IDFC"]
APPS = ["YONO", "Paytm", "PhonePe", "Google Pay", "Net Banking", "Mobile Banking"]
SCAM_TLDS = ["xyz", "top", "shop", "info", "click", "link", "online", "site", "live", "vip", "icu", "cfd", "sbs"]
SHORT = ["bit.ly", "tinyurl.com", "cutt.ly", "rb.gy", "is.gd", "shorturl.at", "t.ly"]
NAMES = ["Rahul", "Priya", "Amit", "Sneha", "Kiran", "Deepa", "Arjun", "Meena", "Ravi", "Anjali", "Suresh", "Pooja"]
COURIERS = ["India Post", "BlueDart", "Delhivery", "DTDC", "FedEx", "Ekart"]
STORES = ["Amazon", "Flipkart", "Myntra", "Swiggy", "Zomato", "BigBasket", "Nykaa", "Meesho", "Ajio"]
BOARDS = ["BESCOM", "MSEB", "TNEB", "KSEB", "BSES", "electricity board", "Electricity Dept"]


def _r(xs):
    return random.choice(xs)


def _phone():
    return _r("6789") + "".join(random.choice("0123456789") for _ in range(9))


def _amt(lo=10, hi=99999):
    return f"{random.randint(lo, hi):,}"


def _slug(*words):
    return "-".join(w.lower().replace(" ", "") for w in words)


def _scam_link(brand="sbi"):
    b = brand.lower().replace(" ", "")
    style = random.random()
    if style < 0.45:
        return f"http://{_slug(b, _r(['kyc', 'verify', 'update', 'secure', 'login', 'reward', 'help']))}.{_r(SCAM_TLDS)}"
    if style < 0.75:
        return f"{_r(SHORT)}/{''.join(random.choice('abcdefghijkmnpqrstuvwxyz0123456789') for _ in range(6))}"
    if style < 0.9:
        return f"https://{b}-{_r(['online', 'care', 'support', 'portal'])}.{_r(['com', 'in', 'net', 'co'])}/{_r(['kyc', 'verify', 'login'])}"
    return f"http://{random.randint(11, 220)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}/{b}"


SCAM_T = [
    # bank / KYC
    lambda: f"Dear {_r(BANKS)} customer, your {_r(APPS)} account will be blocked {_r(['today', 'within 24 hours', 'tonight'])}. Update your {_r(['KYC', 'PAN', 'PAN card', 'Aadhaar'])} immediately: {_scam_link(_r(BANKS))}",
    lambda: f"{_r(BANKS)}: Your account has been {_r(['suspended', 'temporarily blocked', 'frozen', 'deactivated'])} due to incomplete KYC. Click {_scam_link()} to reactivate.",
    lambda: f"Your {_r(BANKS)} netbanking will expire today. Please update PAN to avoid suspension {_scam_link()}",
    lambda: f"URGENT: Your {_r(BANKS)} debit card is blocked. Call customer care {_phone()} to unblock now.",
    lambda: f"Dear user your {_r(BANKS)} reward points worth Rs {_amt(1000, 9999)} expire today. Redeem now {_scam_link()}",
    lambda: f"{_r(BANKS)} ALERT: Unusual login detected. If not you, verify immediately at {_scam_link()} or your account will be closed",
    lambda: f"Your credit card limit increase of Rs.{_amt(50000, 300000)} is approved. Share the OTP received to activate.",
    lambda: f"Dear Customer, KYC verification pending. Your account will be deactivated in 2 hrs. Update: {_scam_link()}",
    # electricity
    lambda: f"Dear consumer your electricity power will be disconnected tonight at {random.randint(8, 11)}.30 pm because your previous month bill was not updated. Please contact electricity officer {_phone()} immediately.",
    lambda: f"{_r(BOARDS)}: Your power supply will be cut today. Last bill not paid. Call {_phone()} to avoid disconnection.",
    lambda: f"Electricity bill pending. Connection will be disconnected tonight. Pay Rs {random.randint(10, 99)} via {_scam_link('bill')} or call {_phone()}",
    # parcel / customs
    lambda: f"{_r(COURIERS)}: Your parcel is on hold due to incomplete address. Update within 12 hours: {_scam_link('indiapost')}",
    lambda: f"Your package could not be delivered. Pay Rs.{random.randint(15, 49)} redelivery fee at {_scam_link('delivery')}",
    lambda: f"FedEx: A parcel in your name contains illegal items and is held by customs. Press 1 or call {_phone()} to speak to officer.",
    lambda: f"Your courier is pending for customs clearance. Pay ₹{random.randint(99, 999)} now to receive it {_scam_link()}",
    # lottery / prize
    lambda: f"Congratulations! You have won Rs {_amt(100000, 2500000)} in KBC lucky draw. To claim pay registration fee ₹{random.randint(500, 9999)}. Contact {_phone()}",
    lambda: f"You are the lucky winner of {_r(['iPhone 15', 'Tata Nexon', 'Rs 25 lakh', 'gold coin'])} from {_r(STORES)}! Claim your prize now {_scam_link(_r(STORES))}",
    lambda: f"Dear customer you won cashback of Rs {_amt(500, 5000)}. Click link to receive in your account {_scam_link('paytm')}",
    lambda: f"Jio lucky draw winner! Free recharge of 1 year. Click {_scam_link('jio')} to activate before midnight",
    # jobs / tasks
    lambda: f"Hi I am {_r(NAMES)} from {_r(['Amazon', 'HR team', 'Google', 'YouTube'])}. Part time job, earn Rs {_amt(2000, 9000)} daily by liking videos. Contact on Telegram {_scam_link('t.me')}",
    lambda: f"Work from home opportunity! Earn {_amt(30000, 90000)} per month. No experience. Registration fee only Rs {random.randint(199, 999)}. WhatsApp {_phone()}",
    lambda: f"Congratulations, you are selected for online task job. Complete simple tasks and get paid daily. Prepaid task investment returns 30%. Join {_scam_link('task')}",
    lambda: f"Dear candidate your profile is shortlisted. Salary {_amt(25000, 80000)}. Pay {_amt(500, 3000)} for ID card and training kit to confirm job.",
    # UPI / refund
    lambda: f"I have sent Rs {_amt(2000, 20000)} to your account by mistake, please return it. I have sent a request, just approve it with your UPI PIN.",
    lambda: f"You have received a payment request of Rs {_amt(500, 9000)} for refund. Enter UPI PIN to receive money.",
    lambda: f"Income tax refund of Rs {_amt(5000, 50000)} approved. Verify your account details to receive: {_scam_link('incometax')}",
    lambda: f"Your {_r(STORES)} order refund of Rs {_amt(300, 6000)} is pending. Share the OTP to process refund.",
    # digital arrest / police
    lambda: f"This is {_r(['CBI', 'Mumbai Police', 'Cyber Crime Department', 'TRAI', 'Customs'])}. Your Aadhaar is linked to money laundering case. Stay on video call or arrest warrant will be issued.",
    lambda: f"TRAI notice: your mobile number will be blocked in 2 hours due to illegal activity. Press 9 to speak to officer.",
    lambda: f"Your SIM card will be deactivated today. Update eKYC immediately by calling {_phone()}",
    # loans / crypto / investment
    lambda: f"Instant loan approved Rs {_amt(10000, 500000)} without documents! Low interest. Click {_scam_link('loan')} pay processing fee {random.randint(199, 1999)}",
    lambda: f"Invest Rs {_amt(5000, 20000)} and get double returns in 7 days. Guaranteed profit crypto trading. Join our VIP group {_scam_link('crypto')}",
    lambda: f"Stock market tips with 100% guaranteed returns. Join WhatsApp group of SEBI registered expert {_scam_link('stocks')}",
    # family emergency / impersonation
    lambda: f"{_r(['Mummy', 'Papa', 'Hi Dad', 'Hi Mom', 'Bhaiya'])}, this is my new number, old phone is lost. Please send Rs {_amt(2000, 20000)} urgently to this UPI, will explain later.",
    lambda: f"Hi I am your {_r(['son', 'daughter', 'nephew'])}'s friend. He met with an accident, need Rs {_amt(10000, 50000)} for hospital immediately. Send to {_phone()}@ybl",
    lambda: f"This is your boss {_r(NAMES)}. I am in a meeting, buy {_r(['Amazon', 'Google Play'])} gift cards worth Rs {_amt(5000, 20000)} urgently and send me the codes.",
    # credentials
    lambda: f"Your {_r(['Netflix', 'Amazon Prime', 'Hotstar'])} subscription is suspended. Update payment details at {_scam_link('netflix')}",
    lambda: f"Dear user, please share the OTP sent to your number to complete verification of your {_r(BANKS)} account.",
    lambda: f"Your gas connection subsidy is pending. Enter card number and CVV at {_scam_link('lpg')} to receive.",
    # Hinglish / Indic
    lambda: f"Aapka {_r(BANKS)} account aaj band ho jayega. Turant KYC update karein {_scam_link()}",
    lambda: f"Aapne Rs {_amt(100000, 2500000)} ka inaam jeeta hai! Claim karne ke liye {_phone()} par call karein",
    lambda: f"आपका बिजली कनेक्शन आज रात काट दिया जाएगा। तुरंत {_phone()} पर संपर्क करें।",
    lambda: f"आपका बैंक खाता ब्लॉक हो जाएगा। केवाईसी अपडेट करें {_scam_link()}",
    lambda: f"ನಿಮ್ಮ ವಿದ್ಯುತ್ ಸಂಪರ್ಕ ಇಂದು ರಾತ್ರಿ ಕಡಿತಗೊಳ್ಳುತ್ತದೆ. ತಕ್ಷಣ {_phone()} ಗೆ ಕರೆ ಮಾಡಿ",
    lambda: f"ನಿಮ್ಮ ಬ್ಯಾಂಕ್ ಖಾತೆ ಬ್ಲಾಕ್ ಆಗುತ್ತದೆ. ಕೆವೈಸಿ ಅಪ್ಡೇಟ್ ಮಾಡಿ {_scam_link()}",
    lambda: f"உங்கள் மின் இணைப்பு இன்று துண்டிக்கப்படும். உடனே {_phone()} அழைக்கவும்",
]

HAM_T = [
    # OTPs (genuine ones warn you)
    lambda: f"{random.randint(100000, 999999)} is your OTP for {_r(BANKS)} transaction of Rs {_amt()}. Do not share it with anyone. Bank never asks for OTP.",
    lambda: f"Your {_r(STORES)} verification code is {random.randint(1000, 999999)}. Never share this code with anyone.",
    lambda: f"OTP for login to {_r(APPS)} is {random.randint(100000, 999999)}. Valid for 5 minutes. Do not share.",
    lambda: f"{random.randint(100000, 999999)} is your one time password to verify your mobile number on {_r(['WhatsApp', 'Swiggy', 'Uber', 'Ola', 'Zepto'])}.",
    # bank alerts
    lambda: f"Rs.{_amt()} debited from A/c XX{random.randint(1000, 9999)} on {random.randint(1, 28)}-{_r(['Jan', 'Feb', 'Mar', 'Apr', 'Nov'])}-26 to {_r(NAMES)}. Avl Bal Rs.{_amt()}. Not you? Call {_r(BANKS)} official helpline.",
    lambda: f"Dear Customer, Rs.{_amt()} credited to your A/c XX{random.randint(1000, 9999)} by UPI. Ref no {random.randint(10**11, 10**12)}. -{_r(BANKS)}",
    lambda: f"Your {_r(BANKS)} credit card statement for {_r(['October', 'November'])} is ready. Total due Rs {_amt()}. Due date {random.randint(1, 28)}th.",
    lambda: f"Salary of Rs {_amt(20000, 150000)} credited to your account XX{random.randint(1000, 9999)}. -{_r(BANKS)}",
    lambda: f"EMI of Rs {_amt(1000, 30000)} for loan account XX{random.randint(1000, 9999)} will be auto-debited on {random.randint(1, 28)}th. Please maintain balance.",
    # deliveries
    lambda: f"Your {_r(STORES)} order #{random.randint(10**6, 10**8)} has been shipped and will arrive by {_r(['tomorrow', 'Friday', 'Monday'])}. Track in the app.",
    lambda: f"{_r(COURIERS)}: Shipment {random.randint(10**8, 10**10)} is out for delivery today. Delivery agent {_r(NAMES)} will call you.",
    lambda: f"Your {_r(STORES)} order was delivered. Rate your experience in the app.",
    lambda: f"Your food from {_r(['Swiggy', 'Zomato'])} is on the way! {_r(NAMES)} will reach in {random.randint(10, 40)} minutes.",
    # utilities (genuine)
    lambda: f"{_r(BOARDS)}: Bill of Rs {_amt(200, 5000)} generated for account {random.randint(10**8, 10**10)}. Due date {random.randint(1, 28)}th. Pay on the official app or website.",
    lambda: f"Thank you for your payment of Rs {_amt(200, 5000)} towards electricity bill. Receipt no {random.randint(10**6, 10**8)}.",
    lambda: f"Your Airtel bill of Rs {_amt(199, 1999)} is generated. Pay via Airtel Thanks app before due date.",
    lambda: f"Recharge of Rs {random.choice([199, 239, 299, 479, 666])} successful on your Jio number. Validity 28 days.",
    # personal chats
    lambda: f"Hi {_r(NAMES)}, are we still meeting for {_r(['lunch', 'dinner', 'coffee', 'the movie'])} {_r(['tomorrow', 'today', 'on Sunday'])}?",
    lambda: f"{_r(['Happy birthday', 'Congrats on the new job', 'Happy Diwali', 'Happy anniversary'])} {_r(NAMES)}! Have a great day 🎉",
    lambda: f"Mom, I reached {_r(['office', 'college', 'home', 'the station'])}. Will call you later.",
    lambda: f"Can you send me the {_r(['notes', 'photos', 'address', 'bill', 'ppt'])} from {_r(['yesterday', 'the trip', 'class', 'the meeting'])}?",
    lambda: f"Running {random.randint(5, 30)} minutes late, stuck in traffic near {_r(['Silk Board', 'MG Road', 'Andheri', 'Hitech City'])}.",
    lambda: f"Did you finish the {_r(['assignment', 'report', 'project', 'presentation'])}? Deadline is {_r(['tomorrow', 'Friday', 'next week'])}.",
    lambda: f"Bhai kal {_r(['cricket', 'movie', 'party', 'class'])} hai kya? Kitne baje?",
    lambda: f"Ok sure, I will {_r(['pay you back', 'bring it', 'call you', 'check and tell'])} {_r(['tonight', 'tomorrow', 'in the evening'])}.",
    lambda: f"Meeting moved to {random.randint(2, 6)} pm. Link is in the calendar invite.",
    lambda: f"Sent you Rs {_amt(100, 3000)} for {_r(['dinner', 'the cab', 'tickets', 'groceries'])} on GPay. Check once.",
    lambda: f"Kal subah {random.randint(6, 10)} baje milte hain. Ghar pe sab theek?",
    lambda: f"ನಾಳೆ ಬೆಳಿಗ್ಗೆ {random.randint(6, 10)} ಗಂಟೆಗೆ ಸಿಗೋಣ. ಊಟ ಆಯ್ತಾ?",
    lambda: f"कल शाम {random.randint(5, 8)} बजे घर आ जाना। खाना साथ में खाएंगे।",
    lambda: f"நாளை காலை {random.randint(6, 10)} மணிக்கு சந்திப்போம்.",
    # genuine offers / info
    lambda: f"{_r(STORES)} sale is live! Up to {random.randint(20, 80)}% off on {_r(['fashion', 'electronics', 'groceries', 'beauty'])}. Shop now in the app.",
    lambda: f"Your appointment with Dr. {_r(NAMES)} is confirmed for {_r(['tomorrow', 'Monday'])} at {random.randint(9, 12)} am. Clinic address sent on email.",
    lambda: f"PNR {random.randint(10**9, 10**10 - 1)}: Train {random.randint(10000, 22999)} confirmed. Coach S{random.randint(1, 9)} berth {random.randint(1, 72)}. -IRCTC",
    lambda: f"Your Uber ride with {_r(NAMES)} is arriving in {random.randint(2, 9)} min. Vehicle KA{random.randint(1, 60)} {random.randint(1000, 9999)}.",
    lambda: f"Reminder: your {_r(['LIC', 'health insurance', 'car insurance'])} premium of Rs {_amt(1000, 30000)} is due on {random.randint(1, 28)}th. Pay via official app or branch.",
    lambda: f"{_r(BANKS)} never asks for your PIN, OTP or password over call or SMS. Stay safe from fraud.",
    lambda: f"Your Aadhaar was used for authentication on {random.randint(1, 28)}/11/2026. If not you, report on uidai.gov.in",
]


def build(n_per_class: int = 800, seed: int = 42) -> tuple[list[str], list[int], list[str]]:
    """Returns (texts, labels, groups) with 1 = scam, 0 = normal.
    groups = which template made the example, so we can test on templates the model never saw."""
    random.seed(seed)
    texts, labels, groups = [], [], []
    for _ in range(n_per_class):
        i = random.randrange(len(SCAM_T)); texts.append(SCAM_T[i]()); labels.append(1); groups.append(f"s{i}")
        j = random.randrange(len(HAM_T)); texts.append(HAM_T[j]()); labels.append(0); groups.append(f"h{j}")
    return texts, labels, groups
