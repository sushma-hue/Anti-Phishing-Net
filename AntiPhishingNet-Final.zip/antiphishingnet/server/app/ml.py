"""Scam-text ML model (TF-IDF + Logistic Regression).

- Learns from ml_data (Indian scam + normal messages) plus user feedback (data/feedback.jsonl).
- Works in any script: word n-grams + character n-grams, so Hindi / Kannada / Hinglish all get features.
- Links, phone numbers and amounts are replaced with tokens so it learns patterns, not specific values.
- Rules explain *why*; the model adds a probability that catches new wording rules miss.
"""
import json
import re
import threading
import time
from pathlib import Path

import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import accuracy_score, precision_score, recall_score
from sklearn.pipeline import FeatureUnion, Pipeline

from . import ml_data

DATA = Path(__file__).parent.parent / "data"
DATA.mkdir(exist_ok=True)
MODEL_FILE = DATA / "scam_model.joblib"
FEEDBACK_FILE = DATA / "feedback.jsonl"

_URL = re.compile(r"(https?://\S+|www\.\S+|\b[a-z0-9-]+\.(?:[a-z]{2,})(?:/\S*)?)", re.I)
_PHONE = re.compile(r"(?:\+?91[\s-]?)?[6-9]\d{9}\b")
_AMT = re.compile(r"(?:rs\.?|inr|₹)\s?[\d,]+", re.I)
_NUM = re.compile(r"\d+")

_lock = threading.Lock()
_model = None
_meta: dict = {}


def normalize(text: str) -> str:
    def url_tok(m):
        u = m.group(0).lower()
        tld = re.sub(r"[/?#].*$", "", re.sub(r"^https?://", "", u)).rsplit(".", 1)[-1]
        short = any(s in u for s in ("bit.ly", "tinyurl", "cutt.ly", "rb.gy", "is.gd", "shorturl", "t.ly"))
        return f" urltok tld_{tld} {'shorttok' if short else ''} {'httptok' if u.startswith('http://') else ''} "
    t = _URL.sub(url_tok, text)
    t = _PHONE.sub(" phonetok ", t)
    t = _AMT.sub(" amttok ", t)
    t = _NUM.sub(" numtok ", t)
    return t.lower()


def _pipeline() -> Pipeline:
    feats = FeatureUnion([
        ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)),
        ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=2, sublinear_tf=True, max_features=40000)),
    ])
    return Pipeline([("feats", feats), ("clf", LogisticRegression(C=4.0, max_iter=2000, class_weight="balanced"))])


def _feedback() -> tuple[list[str], list[int]]:
    texts, labels = [], []
    if FEEDBACK_FILE.exists():
        for line in FEEDBACK_FILE.read_text(encoding="utf-8").splitlines():
            try:
                o = json.loads(line)
                texts.append(o["text"]); labels.append(int(o["label"]))
            except Exception:
                pass
    return texts, labels


def train() -> dict:
    """(Re)train, evaluate on a held-out 20%, save. Returns metrics."""
    global _model, _meta
    texts, labels, groups = ml_data.build()
    ft, fl = _feedback()
    # Honest test: hold out WHOLE templates (unseen wording), repeated 5x and averaged.
    X0 = [normalize(t) for t in texts]
    accs, precs, recs = [], [], []
    cm = {"tp": 0, "fn": 0, "fp": 0, "tn": 0}  # summed over the 5 test rounds
    for k, (tr, te) in enumerate(GroupShuffleSplit(n_splits=5, test_size=0.25, random_state=7).split(X0, labels, groups)):
        m = _pipeline().fit([X0[i] for i in tr], [labels[i] for i in tr])
        yte = [labels[i] for i in te]; pred = m.predict([X0[i] for i in te])
        accs.append(accuracy_score(yte, pred)); precs.append(precision_score(yte, pred, zero_division=0)); recs.append(recall_score(yte, pred, zero_division=0))
        for y, p in zip(yte, pred):
            cm["tp" if y and p else "fn" if y else "fp" if p else "tn"] += 1
    avg = lambda xs: round(sum(xs) / len(xs), 4)
    # feedback counts 3x: real user corrections matter more than templates
    texts += ft * 3; labels += fl * 3
    X = [normalize(t) for t in texts]
    meta = {
        "accuracy": avg(accs), "precision": avg(precs), "recall": avg(recs),
        "eval": "tested on message templates the model never saw (5 rounds)",
        "train_examples": len(X), "templates": len(set(groups)),
        "feedback_examples": len(ft), "trained_at": time.time(),
        "algorithm": "TF-IDF (words + characters) + Logistic Regression",
    }
    final = _pipeline().fit(X, labels)  # final model uses all data
    meta["confusion"] = cm
    meta["scam_examples"] = sum(labels); meta["normal_examples"] = len(labels) - sum(labels)
    meta["top_words"] = _top_words(final)
    joblib.dump({"model": final, "meta": meta}, MODEL_FILE)
    with _lock:
        _model, _meta = final, meta
    print(f"[ml] trained: acc={meta['accuracy']} prec={meta['precision']} rec={meta['recall']} n={len(X)}")
    return meta


_TOK_NAMES = {"urltok": "[a link]", "phonetok": "[phone number]", "amttok": "[₹ amount]", "numtok": "[a number]",
              "shorttok": "[short link]", "httptok": "[http:// link]"}


def _top_words(model, n: int = 15) -> dict:
    """The words/phrases that push the model most towards 'scam' and towards 'normal'."""
    try:
        word_vec = model.named_steps["feats"].transformer_list[0][1]
        names = word_vec.get_feature_names_out()
        coef = model.named_steps["clf"].coef_[0][: len(names)]  # word features come first in the union
        pretty = lambda w: " ".join(_TOK_NAMES.get(p, ".%s domain" % p[4:] if p.startswith("tld_") else p) for p in w.split())
        order = coef.argsort()
        stop = {"to", "be", "on", "for", "you", "the", "in", "is", "of", "and", "a", "your", "will", "it", "at",
                "has", "by", "this", "with", "from", "or", "are", "xx", "we", "our", "my", "me", "now", "has been"}
        def pick(idx):
            out = []
            for i in idx:
                w = names[i]
                if all(p in stop or p == "numtok" for p in w.split()) or len(out) >= n:
                    continue
                out.append([pretty(w), round(float(coef[i]), 2)])
            return out
        return {"scam": pick(order[::-1]), "normal": pick(order)}
    except Exception as e:
        print(f"[ml] top words failed: {e}")
        return {"scam": [], "normal": []}


def dataset_rows() -> list[tuple[str, str, str]]:
    """The training dataset as (text, label, template) for download."""
    texts, labels, groups = ml_data.build()
    return [(t, "scam" if y else "normal", g) for t, y, g in zip(texts, labels, groups)]


def load():
    global _model, _meta
    if MODEL_FILE.exists():
        try:
            d = joblib.load(MODEL_FILE)
            _model, _meta = d["model"], d["meta"]
            print(f"[ml] loaded model (acc={_meta.get('accuracy')})")
            return
        except Exception as e:
            print(f"[ml] load failed, retraining: {e}")
    train()


def scam_probability(text: str) -> float | None:
    if _model is None:
        return None
    try:
        return float(_model.predict_proba([normalize(text)])[0][1])
    except Exception as e:
        print(f"[ml] predict failed: {e}")
        return None


def add_feedback(text: str, is_scam: bool):
    """Explicit user feedback (website 'Was this right?'). Only stored when the user clicks it."""
    with FEEDBACK_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"text": text[:1000], "label": 1 if is_scam else 0, "ts": time.time()}, ensure_ascii=False) + "\n")


def info() -> dict:
    return {**_meta, "pending_feedback": len(_feedback()[0]) - _meta.get("feedback_examples", 0)}
