"""Community scam list: websites and phone numbers seen in scam messages by many users.

- Fed by (a) checks the analyzer rates Phishing, (b) explicit user reports.
- Counts DISTINCT people (hashed user id / IP), so one person re-checking the same text can't inflate it.
- Lookup is by SHA-256; the public list shows the domain and a MASKED phone (98XXXXXX10). Never message text.
- Saved to data/community.json, so it survives server restarts even without Firebase.
"""
import json
import re
import threading
import time
from pathlib import Path

from . import storage, url_checks

FILE = Path(__file__).parent.parent / "data" / "community.json"
FILE.parent.mkdir(exist_ok=True)
_lock = threading.Lock()
_db: dict[str, dict] = {}  # hash -> entry

PHONE_RE = re.compile(r"(?:\+?91[\s-]?)?([6-9]\d{9})\b")
# never list these (legit sites people mention; shorteners are judged per link elsewhere)
NEVER = url_checks.OFFICIAL_DOMAINS | url_checks.SHORTENERS | {
    "google.com", "youtube.com", "whatsapp.com", "facebook.com", "instagram.com", "t.me", "telegram.me",
    "wa.me", "gov.in", "nic.in", "cybercrime.gov.in", "amazon.in", "flipkart.com", "paytm.com"}


def _load():
    global _db
    if FILE.exists():
        try:
            _db = json.loads(FILE.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[community] load failed: {e}")
    _restore()


_restore_at = {"next": 0.0}  # 0 = try now, inf = done
_unsynced: set[str] = set()  # entries changed before the restore finished (not yet in Firestore)


def _restore():
    """The host's disk is wiped on every restart/deploy -> restore from Firestore.
    If Firestore is unavailable (e.g. daily quota used up), retry every 5 minutes."""
    if not storage._db or time.time() < _restore_at["next"]:
        return
    try:
        n = 0
        saved_all = {d.id: d.to_dict() for d in storage._db.collection("community").stream()}
        with _lock:
            for h, saved in saved_all.items():
                cur = _db.get(h)
                if cur and h in _unsynced:  # seen since restart: add the new activity on top
                    saved["checks"] = saved.get("checks", 0) + cur.get("checks", 0)
                    saved["reports"] = saved.get("reports", 0) + cur.get("reports", 0)
                    saved["people"] = (saved.get("people", []) + [p for p in cur["people"] if p not in saved.get("people", [])])[-500:]
                    saved["flags"] = saved.get("flags", []) + [f for f in cur.get("flags", []) if f not in saved.get("flags", [])]
                    saved["last"] = max(saved.get("last", 0), cur.get("last", 0))
                    _db[h] = saved
                elif not cur or saved.get("checks", 0) > cur.get("checks", 0):
                    _db[h] = saved
                n += 1
            _restore_at["next"] = float("inf")
            pending = [(h, dict(_db[h])) for h in _unsynced if h in _db]
            _unsynced.clear()
            _save()
        for h, e in pending:
            _backup(h, e)
        print(f"[community] restored {n} entries from Firestore, synced {len(pending)} new")
    except Exception as e:
        _restore_at["next"] = time.time() + 300
        print(f"[community] Firestore restore failed, retrying in 5 min: {e}")


def _backup(h: str, e: dict):
    if storage._db:
        try:
            storage._db.collection("community").document(h).set(e)
        except Exception as ex:
            print(f"[community] Firestore backup failed: {ex}")


def _save():
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(_db, ensure_ascii=False), encoding="utf-8")
    tmp.replace(FILE)


def mask_phone(p: str) -> str:
    return p[:2] + "XXXXXX" + p[-2:]


def indicators(text: str, urls: list[str]) -> list[tuple[str, str, str]]:
    """-> [(kind, key, display)] for every website / phone number in the message."""
    out, seen = [], set()
    for u in urls:
        d = url_checks.registered_domain(u)
        if d and d not in NEVER and d not in seen:
            seen.add(d); out.append(("website", d, d))
    for m in PHONE_RE.finditer(text):
        p = m.group(1)
        if p not in seen:
            seen.add(p); out.append(("phone", p, mask_phone(p)))
    return out


def lookup(key: str) -> dict | None:
    return _db.get(storage.sha(key))


def record(kind: str, key: str, display: str, who: str, flags: list[str] | None = None, reported: bool = False):
    h = storage.sha(key)
    who_h = storage.sha(who or "anon")[:16]
    now = time.time()
    with _lock:
        e = _db.setdefault(h, {"kind": kind, "display": display, "people": [], "checks": 0,
                               "reports": 0, "first": now, "flags": []})
        e["checks"] += 1
        e["last"] = now
        if reported:
            e["reports"] += 1
        if who_h not in e["people"]:
            e["people"] = (e["people"] + [who_h])[-500:]
        for f in flags or []:
            if f not in e["flags"]:
                e["flags"].append(f)
        _save()
        restored = _restore_at["next"] == float("inf") or not storage._db
        if not restored:
            _unsynced.add(h)  # don't overwrite the saved copy before we've read it
        snapshot = dict(e)
    if restored:
        _backup(h, snapshot)
    else:
        _restore()
    # also feed the shared indicator DB (Zoho Catalyst when configured)
    if reported or len(e["people"]) >= 2:
        storage.add_scam_indicator(key, kind)


def people(e: dict) -> int:
    return len(e.get("people", []))


def top(limit: int = 20, days: float = 30) -> list[dict]:
    _restore()
    cutoff = time.time() - days * 86400
    rows = [e for e in _db.values() if e.get("last", 0) >= cutoff]
    rows.sort(key=lambda e: (people(e) + 2 * e.get("reports", 0), e.get("last", 0)), reverse=True)
    return [{"kind": e["kind"], "value": e["display"], "people": people(e), "reports": e.get("reports", 0),
             "checks": e["checks"], "first": e["first"], "last": e["last"], "flags": e.get("flags", [])[:6]}
            for e in rows[:limit]]


def summary() -> dict:
    _restore()
    vals = list(_db.values())
    return {"websites": sum(1 for e in vals if e["kind"] == "website"),
            "phones": sum(1 for e in vals if e["kind"] == "phone"),
            "total": len(vals)}


_load()
