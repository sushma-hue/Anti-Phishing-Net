"""The 7 jury test cases. Run: pytest -v   (offline: no network, no API keys needed)"""
import os

os.environ["CHECK_NETWORK"] = "0"
os.environ["SARVAM_API_KEY"] = ""

import pytest
from fastapi.testclient import TestClient

from app import url_checks
from app.main import app

client = TestClient(app)


def check(text):
    r = client.post("/check", json={"text": text, "source": "test"})
    assert r.status_code == 200
    return r.json()


def test_1_sbi_kyc_shortlink():
    r = check("Your SBI KYC expired, update now: bit.ly/xyz")
    assert r["verdict"] == "Phishing", r


def test_2_electricity_disconnection():
    r = check("Electricity will be disconnected tonight, call 98xxxxxxxx")
    assert r["verdict"] == "Phishing", r


def test_3_genuine_otp_safe():
    r = check("482913 is your OTP for txn of Rs 1,250 at HDFC Bank. Do not share it with anyone.")
    assert r["verdict"] == "Safe", r


def test_4_amazon_lookalike():
    r = check("Big Diwali sale! http://amaz0n-offer.xyz")
    assert r["verdict"] == "Phishing", r
    assert "lookalike" in r["flags"]


def test_5_kannada_courier():
    r = check("ನಿಮ್ಮ ಪಾರ್ಸೆಲ್ ಹಿಡಿಯಲಾಗಿದೆ, ₹50 ಕಟ್ಟಿ")
    assert r["language"] == "kn-IN"
    assert r["verdict"] == "Phishing", r


def test_6_new_domain_suspicious(monkeypatch):
    monkeypatch.setattr(url_checks, "domain_age_days", lambda d: 5)
    r = check("Hey, check out this store http://fresh-deals-store.com")
    assert r["verdict"] == "Suspicious", r
    assert "new_domain" in r["flags"]


def test_7_casual_safe():
    r = check("Meet at 5pm?")
    assert r["verdict"] == "Safe" and r["risk_score"] == 0, r


# ---- extra checks ----
def test_official_domain_not_flagged():
    r = check("Your statement is ready on https://www.hdfcbank.com")
    assert r["verdict"] == "Safe", r


@pytest.mark.parametrize("host,brand", [("paytrn.com", "paytm"), ("sbi-kyc-update.top", "sbi"),
                                        ("flipkrt.com", "flipkart"), ("rnyntra.com", None)])
def test_lookalike(host, brand):
    assert url_checks.lookalike_brand("http://" + host) == brand


def test_report_feeds_known_scam_db():
    client.post("/report", json={"urls": ["http://totally-normal-site.com"]})
    r = check("hello http://totally-normal-site.com")
    assert "known_scam" in r["flags"]


def test_whatsapp_verify():
    r = client.get("/webhook/whatsapp", params={"hub.mode": "subscribe",
                   "hub.verify_token": "phishingnet-verify", "hub.challenge": "42"})
    assert r.text == "42"


def test_whatsapp_incoming_end_to_end(monkeypatch):
    from app import whatsapp
    sent = []
    monkeypatch.setattr(whatsapp, "send_text", lambda to, body: sent.append((to, body)))
    payload = {"entry": [{"changes": [{"value": {"messages": [
        {"from": "919999999999", "type": "text", "text": {"body": "Your SBI KYC expired, update now: bit.ly/xyz"}}]}}]}]}
    assert client.post("/webhook/whatsapp", json=payload).status_code == 200
    assert sent and "Phishing" in sent[0][1] and "1930" in sent[0][1]
