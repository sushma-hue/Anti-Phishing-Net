"""Direct Zoho Catalyst write + read test: python -m tests.try_zoho"""
from app import storage

storage._known_scams.clear()
print("enabled:", storage._zoho_enabled())
r = storage._catalyst("POST", f"/table/{storage.config.CATALYST_TABLE}/row",
                      json=[{"hash": storage.sha("zoho-test.example"), "kind": "test", "reported_at": 0}])
print("insert:", r.status_code, r.text[:200])
storage._known_scams.clear()
print("lookup finds it:", storage.is_known_scam("zoho-test.example"))
