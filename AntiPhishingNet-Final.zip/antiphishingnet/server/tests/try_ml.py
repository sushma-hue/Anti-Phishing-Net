"""Quick manual check of the ML model: python -m tests.try_ml"""
from app import ml

ml.train()
tests = [
    "Your SBI account will be blocked today, update KYC http://sbi-kyc.xyz",
    "Hey, dinner at 8 tonight?",
    "Rs.500 debited from A/c XX1234. Not you? call bank helpline",
    "Dear customer your Netflix account is on hold, verify card details at netflix-billing.help",
    "Congrats! Selected for Amazon work from home, earn 5000 per day, contact on telegram",
    "Your order from Flipkart has been shipped",
    "Papa please send 2000 urgently to this new number, my phone is lost",
    "ನಮಸ್ಕಾರ, ಊಟ ಆಯ್ತಾ? ನಾಳೆ ಸಿಗೋಣ",
    "Your electricity will be cut tonight call 9876543210",
]
for t in tests:
    print(f"{ml.scam_probability(t):.2f}  {t[:70]}")
