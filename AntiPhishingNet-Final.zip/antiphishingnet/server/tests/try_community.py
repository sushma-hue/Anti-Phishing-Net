"""Manual end-to-end check against the running server: python -m tests.try_community"""
import httpx

B = "http://localhost:8000"
msg = "Dear SBI customer your account is blocked. Update KYC at http://sbi-secure-kyc.xyz or call 9123456780"
for user in ("userA", "userB", "userC"):
    r = httpx.post(f"{B}/check", json={"text": msg, "source": "sms", "user_id": user}, timeout=30).json()
    print(user, r["verdict"], r["risk_score"], "ml=", r["ml_probability"])
print("reasons for userC:", *r["reasons"], sep="\n  ")
# a NEW message reusing the same number, wording the rules don't know
r = httpx.post(f"{B}/check", json={"text": "hello sir pls call 9123456780 regarding your pending amount", "user_id": "userD"}, timeout=30).json()
print("new msg w/ known number:", r["verdict"], r["risk_score"], r["reasons"])
print(httpx.get(f"{B}/api/community").json())
print(httpx.get(f"{B}/api/lookup", params={"q": "sbi-secure-kyc.xyz"}).json())
print(httpx.get(f"{B}/api/lookup", params={"q": "google.com"}).json())
print(httpx.get(f"{B}/api/model").json())
r = httpx.post(f"{B}/check", json={"text": "Hi, are we meeting for lunch tomorrow?"}, timeout=30).json()
print("normal:", r["verdict"], r["risk_score"], r["ml_probability"])
