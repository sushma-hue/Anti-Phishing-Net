"""Builds server/render.env: every secret in one paste for Render's 'Add from .env'. Never committed.
python -m tests.make_render_env
"""
import json
from pathlib import Path

from dotenv import dotenv_values

root = Path(__file__).parent.parent
v = {k: (x or "") for k, x in dotenv_values(root / ".env").items()}
v.pop("FIREBASE_CREDENTIALS", None)
v.pop("ZOHO_GRANT_CODE", None)
sa = root / "firebase-service-account.json"
if sa.exists():
    v["FIREBASE_CREDENTIALS_JSON"] = json.dumps(json.loads(sa.read_text(encoding="utf-8")), separators=(",", ":"))
lines = [f"{k}='{x}'" if k == "FIREBASE_CREDENTIALS_JSON" else f"{k}={x}" for k, x in v.items() if x]
(root / "render.env").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("wrote render.env with:", ", ".join(k for k, x in v.items() if x))
