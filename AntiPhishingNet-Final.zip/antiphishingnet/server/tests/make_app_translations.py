"""Pre-translates the Android app's UI strings so language switching is instant (no on-phone download).
Writes android/app/src/main/assets/i18n/<lang>.json. Run from server/:  python -m tests.make_app_translations
"""
import json
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from app import sarvam

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "android/app/src/main/java/com/phishingnet/app"
OUT = ROOT / "android/app/src/main/assets/i18n"
LANGS = ["hi", "kn", "ta", "te", "ml", "mr", "bn"]
# must match I18n.kt
KEEP = ["Phishing Net", "WhatsApp", "Telegram", "Gmail", "SMS", "OTP", "UPI", "KYC", "PAN", "Aadhaar",
        "QR", "PIN", "CVV", "SBI", "HDFC", "KBC"]
PHONE_OR_LINK = re.compile(r"\d{6,}|https?://|www\.|@|\.(com|in|xyz|top)\b")


def strings() -> list[str]:
    out = set()
    for f in SRC.glob("*.kt"):
        for line in f.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith(("//", "*", "import", "package")):
                continue
            for s in re.findall(r'"((?:[^"\\\n]|\\.)*)"', line):
                if "$" in s or not s[:1].isupper() or len(s) < 3:
                    continue  # templates are translated live; UI text starts with a capital
                if re.search(r"[{}=<>|]|\(\)", s) or PHONE_OR_LINK.search(s):
                    continue
                if " " not in s.replace("\\n", " ") and not s.isalpha():
                    continue
                out.add(s.replace("\\n", "\n").replace('\\"', '"'))
    return sorted(out)


def protect(s):
    for i, w in enumerate(KEEP):
        s = s.replace(w, f"⟦{i}⟧")
    return s


def restore(s):
    for i, w in enumerate(KEEP):
        s = s.replace(f"⟦{i}⟧", w).replace(f"⟦ {i} ⟧", w)
    return s


def main():
    texts = strings()
    print(len(texts), "strings")
    OUT.mkdir(parents=True, exist_ok=True)
    import time
    for lang in LANGS:
        f = OUT / f"{lang}.json"
        pairs = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}

        def one(en):
            for attempt in range(3):  # Sarvam rate-limits bursts: retry with a pause
                tx = sarvam.localize(protect(en), f"{lang}-IN")
                if tx and tx != protect(en):
                    return en, restore(tx)
                time.sleep(1.5 * (attempt + 1))
            return en, en
        todo = [t for t in texts if t not in pairs]
        with ThreadPoolExecutor(max_workers=3) as ex:
            pairs.update(p for p in ex.map(one, todo) if p[1] and p[1] != p[0] and "⟦" not in p[1])
        f.write_text(json.dumps(pairs, ensure_ascii=False, indent=0), encoding="utf-8")
        print(lang, len(pairs), "/", len(texts), "translated")


if __name__ == "__main__":
    main()
