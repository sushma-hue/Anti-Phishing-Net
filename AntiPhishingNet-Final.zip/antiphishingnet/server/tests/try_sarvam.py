"""Manual Sarvam check against the running server: python -m tests.try_sarvam"""
import httpx

B = "http://localhost:8000"
print(httpx.get(f"{B}/health").json()["backends"])
for text, lang in [
    ("आपका बैंक खाता आज बंद हो जाएगा। तुरंत केवाईसी अपडेट करें http://sbi-kyc.xyz", "hi-IN"),
    ("ನಿಮ್ಮ ವಿದ್ಯುತ್ ಸಂಪರ್ಕ ಇಂದು ರಾತ್ರಿ ಕಡಿತಗೊಳ್ಳುತ್ತದೆ. ತಕ್ಷಣ 9876543210 ಗೆ ಕರೆ ಮಾಡಿ", "kn-IN"),
]:
    r = httpx.post(f"{B}/check", json={"text": text, "source": "web", "reply_language": lang}, timeout=60).json()
    print("\n", lang, r["verdict"], r["risk_score"], "| detected:", r["language"])
    print("  translated:", r["translated_text"])
    print("  reasons:", r["reasons_localized"][:3])
print("\nUI:", httpx.post(f"{B}/translate", json={"texts": ["Check before you click", "Scan message"], "target": "kn-IN"}, timeout=60).json())
