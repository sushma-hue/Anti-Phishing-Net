"""One-time: swap a Zoho grant code for a refresh token and save it into .env (never printed).
Usage: put ZOHO_CLIENT_ID, ZOHO_CLIENT_SECRET, ZOHO_GRANT_CODE in .env, then
       python -m tests.zoho_token
"""
import re
from pathlib import Path

import httpx
from dotenv import dotenv_values

ENV = Path(__file__).parent.parent / ".env"
v = dotenv_values(ENV)
for k in ("ZOHO_CLIENT_ID", "ZOHO_CLIENT_SECRET", "ZOHO_GRANT_CODE"):
    if not (v.get(k) or "").strip():
        raise SystemExit(f"{k} is empty in .env")

r = httpx.post("https://accounts.zoho.in/oauth/v2/token", data={
    "grant_type": "authorization_code", "client_id": v["ZOHO_CLIENT_ID"].strip(),
    "client_secret": v["ZOHO_CLIENT_SECRET"].strip(), "code": v["ZOHO_GRANT_CODE"].strip()}, timeout=20).json()
if "refresh_token" not in r:
    raise SystemExit(f"Zoho said: {r.get('error', r)}")

text = ENV.read_text(encoding="utf-8")
text = re.sub(r"(?m)^ZOHO_REFRESH_TOKEN=.*$", "ZOHO_REFRESH_TOKEN=" + r["refresh_token"], text)
text = re.sub(r"(?m)^ZOHO_GRANT_CODE=.*$", "ZOHO_GRANT_CODE=", text)  # one-time code, clear it
ENV.write_text(text, encoding="utf-8")
print("OK: refresh token saved to .env (scopes:", r.get("scope", "?"), ")")
