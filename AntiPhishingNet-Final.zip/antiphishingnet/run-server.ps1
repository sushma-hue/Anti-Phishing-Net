# Starts the validation server on all interfaces (phone on same Wi-Fi can reach it)
Set-Location "$PSScriptRoot\server"
.\.venv\Scripts\python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
