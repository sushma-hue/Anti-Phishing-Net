# Builds android APK -> PhishingNet.apk  (uses portable JDK 17 + Gradle in .tools)
New-Item -ItemType Directory -Force E:\pntmp | Out-Null
$env:TMP="E:\pntmp"; $env:TEMP="E:\pntmp"
$env:JAVA_HOME="$PSScriptRoot\.tools\jdk-17.0.21+9"
$env:JAVA_TOOL_OPTIONS="-Djdk.net.unixdomain.tmpdir=E:/pntmp -Djava.io.tmpdir=E:/pntmp"
& "$PSScriptRoot\android\gradlew.bat" -p "$PSScriptRoot\android" assembleDebug
Copy-Item "$PSScriptRoot\android\app\build\outputs\apk\debug\app-debug.apk" "$PSScriptRoot\PhishingNet.apk" -Force
